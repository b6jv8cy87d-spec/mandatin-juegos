import { HandTracker } from '../handTracking.js';
import { Flashlight, handInput, handsByPlayer } from './controles.js';
import { savedMission } from './mision.js';

const $ = (id) => document.getElementById(id);
const video = $('video');
const overlay = $('overlay');
const mirror = $('mirror');
const camera = $('camera');
const chooser = $('image-file');
const question = $('mission-text');
const example = { file: null, prompt: '¿Puedes encontrar la llave dorada?', name: 'El invernadero secreto' };
const exampleUrl = new URL('../objetos-perdidos/invernadero-ilustrado.webp', import.meta.url).href;
const players = [...document.querySelectorAll('.player')].map((panel) => ({
  board: panel.querySelector('.board'),
  image: panel.querySelector('.scene-image'),
  status: panel.querySelector('.lamp-status'),
  lamp: new Flashlight(),
  wrist: null
}));
const clamp = (value) => Math.max(0, Math.min(1, value));
let count = 1;
let currentView = 'menu';
let mission = example;
let draft = example;
let missionUrl = exampleUrl;
let draftUrl = exampleUrl;
let uploadId = 0;
let loadingDraft = false;
let revealed = false;
let tracker = null;
let ready = false;
let lastResult = -1;
let frameId = 0;
let cameraId = '';

function show(view) {
  currentView = view;
  for (const name of ['menu', 'setup', 'game']) $(name).hidden = name !== view;
  window.scrollTo(0, 0);
}

function setPlayers(amount) {
  count = amount;
  $('solo').setAttribute('aria-pressed', String(count === 1));
  $('duo').setAttribute('aria-pressed', String(count === 2));
  $('player2').hidden = count === 1;
  $('boards').classList.toggle('duo', count === 2);
  $('lanes').hidden = count === 1;
  $('lane-tip').textContent = count === 2
    ? 'Cada jugador usa una mano en su mitad de la cámara. Guíense por J1 y J2 en la vista previa.'
    : 'Muestra una mano y apunta con el índice.';
}

function render(player) {
  const { board, lamp, status } = player;
  board.classList.toggle('aiming', lamp.present);
  board.classList.toggle('lit', lamp.lit);
  board.classList.toggle('burned', lamp.burnedOut);
  board.classList.toggle('revealed', revealed);
  if (lamp.point) {
    board.style.setProperty('--x', `${lamp.point.x * 100}%`);
    board.style.setProperty('--y', `${lamp.point.y * 100}%`);
  }
  const label = revealed ? 'Imagen revelada' : lamp.burnedOut
    ? (tracker ? 'Apagada · haz una pinza' : 'Apagada · toca o pulsa Espacio')
    : lamp.lit ? '● Linterna encendida'
      : tracker ? 'Muestra una mano' : 'Mueve el puntero para iluminar';
  if (status.textContent !== label) status.textContent = label;
}

function resetLights() {
  for (const player of players) {
    player.lamp.reset();
    player.wrist = null;
    render(player);
  }
  lastResult = -1;
}

function toggleReveal(value) {
  revealed = value;
  $('reveal').setAttribute('aria-pressed', String(value));
  $('reveal').textContent = value ? 'Volver a ocultar' : 'Revelar imagen';
  resetLights();
}

function setMission(value) {
  if (missionUrl !== exampleUrl) URL.revokeObjectURL(missionUrl);
  mission = value;
  missionUrl = value.file ? URL.createObjectURL(value.file) : exampleUrl;
}

function setDraft(value, url = value.file ? URL.createObjectURL(value.file) : exampleUrl) {
  if (draftUrl !== exampleUrl) URL.revokeObjectURL(draftUrl);
  draft = value;
  draftUrl = url;
  $('draft-image').src = url;
  $('draft-name').textContent = value.name;
}

function openSetup() {
  setDraft(mission);
  question.value = mission.prompt;
  chooser.value = '';
  $('setup-status').textContent = '';
  show('setup');
  chooser.focus({ preventScroll: true });
}

function startGame() {
  $('question').textContent = mission.prompt || '¿Qué se esconde en la oscuridad?';
  for (const player of players) player.image.src = missionUrl;
  toggleReveal(false);
  show('game');
  players[0].board.focus({ preventScroll: true });
}

function pointOn(event, board) {
  const bounds = board.getBoundingClientRect();
  return {
    x: clamp((event.clientX - bounds.left) / bounds.width),
    y: clamp((event.clientY - bounds.top) / bounds.height)
  };
}

function setPointer(player, event, ignite = false) {
  if (tracker || revealed) return;
  const now = performance.now();
  if (ignite) player.lamp.ignite(now);
  player.lamp.move({ point: pointOn(event, player.board) }, now);
  render(player);
}

for (const player of players) {
  const { board, lamp } = player;
  board.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || tracker) return;
    if (event.pointerType !== 'mouse') board.setPointerCapture(event.pointerId);
    setPointer(player, event, true);
  });
  board.addEventListener('pointermove', (event) => setPointer(player, event));
  const release = () => {
    if (tracker) return;
    lamp.release();
    render(player);
  };
  board.addEventListener('pointerleave', release);
  board.addEventListener('pointercancel', release);
  board.addEventListener('pointerup', (event) => { if (event.pointerType !== 'mouse') release(); });
  board.addEventListener('keydown', (event) => {
    if (tracker || revealed) return;
    const deltas = { ArrowLeft: [-0.055, 0], ArrowRight: [0.055, 0], ArrowUp: [0, -0.055], ArrowDown: [0, 0.055] };
    const delta = deltas[event.key];
    const center = lamp.point || { x: 0.5, y: 0.5 };
    const now = performance.now();
    if (delta) {
      lamp.move({ point: { x: clamp(center.x + delta[0]), y: clamp(center.y + delta[1]) } }, now);
    } else if (event.key === ' ' || event.key === 'Enter') {
      lamp.ignite(now);
      lamp.move({ point: center }, now);
    } else {
      return;
    }
    event.preventDefault();
    render(player);
  });
}

function setMirror() {
  $('feed').classList.toggle('mirrored', mirror.checked);
  if (ready) resetLights();
}

function clearHands() {
  for (const player of players) {
    if (!player.lamp.present) continue;
    player.lamp.release();
    player.wrist = null;
    render(player);
  }
}

function detect() {
  if (!ready) return;
  frameId = requestAnimationFrame(detect);
  if (document.hidden || revealed) return;
  tracker.detectFrame();
  const sample = tracker.lastResultAt;
  if (performance.now() - sample > 380) {
    clearHands();
    return;
  }
  if (sample === lastResult) return;
  lastResult = sample;
  const aspect = video.videoWidth / video.videoHeight || 4 / 3;
  const slots = handsByPlayer(tracker.latestHands, count, mirror.checked, players.map((player) => player.wrist));
  for (const [index, hand] of slots.entries()) {
    const player = players[index];
    const lamp = player.lamp;
    if (hand) {
      player.wrist = hand[0];
      lamp.move(handInput(hand, { players: count, index, mirrored: mirror.checked, aspect, pinching: lamp.pinching }), sample);
    } else {
      lamp.release();
      player.wrist = null;
    }
    render(player);
  }
}

function stopCamera(message = 'Cámara apagada. Puedes usar el mouse o la pantalla táctil.') {
  cancelAnimationFrame(frameId);
  ready = false;
  const stopped = tracker;
  tracker = null;
  stopped?.stopCamera();
  camera.textContent = '◉ Activar cámara';
  camera.disabled = false;
  $('camera-placeholder').hidden = false;
  $('feed').hidden = true;
  $('device-label').hidden = true;
  $('camera-status').textContent = message;
  resetLights();
}

async function showDevices(current) {
  const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
  if (tracker !== current) return;
  const cameras = devices.filter((device) => device.kind === 'videoinput' && device.deviceId);
  $('device').replaceChildren(...cameras.map((device, index) =>
    new Option(device.label || `Cámara ${index + 1}`, device.deviceId)));
  cameraId = current.stream?.getVideoTracks()[0]?.getSettings().deviceId || cameraId;
  $('device').value = cameraId;
  $('device-label').hidden = cameras.length < 2;
}

async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    stopCamera('La cámara se puede activar desde localhost o HTTPS.');
    return;
  }
  if (tracker) stopCamera();
  const current = new HandTracker(video, overlay, { numHands: count });
  tracker = current;
  camera.disabled = true;
  camera.textContent = 'Conectando…';
  $('camera-status').textContent = 'Autoriza la cámara si el navegador lo solicita.';
  resetLights();
  try {
    await current.startCamera(cameraId, count === 2 ? 'auto' : 'light');
    if (tracker !== current) return;
    overlay.height = Math.round(overlay.width / (video.videoWidth / video.videoHeight || 4 / 3));
    $('camera-placeholder').hidden = true;
    $('feed').hidden = false;
    camera.textContent = 'Apagar cámara';
    camera.disabled = false;
    await current.initialize((message) => {
      if (tracker === current) $('camera-status').textContent = message;
    });
    if (tracker !== current) return;
    ready = true;
    $('camera-status').textContent = count === 2 ? 'Cámara lista para dos jugadores.' : 'Cámara lista para un jugador.';
    showDevices(current);
    detect();
  } catch (error) {
    if (tracker !== current) return;
    const denied = error.name === 'NotAllowedError';
    const missing = ['NotFoundError', 'NotReadableError', 'OverconstrainedError'].includes(error.name);
    if (missing) cameraId = '';
    stopCamera(denied ? 'Activa el permiso de cámara en el navegador y vuelve a intentar.'
      : missing ? 'No se pudo abrir esa cámara. Revisa la conexión o si otra app la está usando.'
        : 'No se pudo cargar el seguimiento. Revisa tu conexión o prueba con el mouse.');
  } finally {
    if (tracker !== current) {
      current.stream?.getTracks().forEach((track) => track.stop());
      current.worker?.terminate();
      current.handLandmarker?.close();
    }
  }
}

$('solo').addEventListener('click', () => setPlayers(1));
$('duo').addEventListener('click', () => setPlayers(2));
$('play').addEventListener('click', startGame);
$('prepare').addEventListener('click', openSetup);
$('back').addEventListener('click', () => {
  stopCamera();
  show('menu');
  $('play').focus({ preventScroll: true });
});
$('cancel-setup').addEventListener('click', () => {
  uploadId++;
  loadingDraft = false;
  $('save').disabled = false;
  show('menu');
  $('prepare').focus({ preventScroll: true });
});
$('reveal').addEventListener('click', () => toggleReveal(!revealed));
mirror.addEventListener('change', setMirror);
camera.addEventListener('click', () => { if (tracker) stopCamera(); else startCamera(); });
$('device').addEventListener('change', () => {
  cameraId = $('device').value;
  startCamera();
});
window.addEventListener('pagehide', () => stopCamera());
document.addEventListener('visibilitychange', clearHands);

chooser.addEventListener('change', async () => {
  const [file] = chooser.files;
  if (!file) return;
  const ticket = ++uploadId;
  const status = $('setup-status');
  status.textContent = '';
  if (file.size > 24 * 1024 * 1024) {
    loadingDraft = false;
    $('save').disabled = false;
    status.textContent = 'Elige una imagen de hasta 24 MB.';
    return;
  }
  loadingDraft = true;
  $('save').disabled = true;
  const url = URL.createObjectURL(file);
  try {
    const probe = new Image();
    probe.src = url;
    await probe.decode();
    if (!probe.naturalWidth || !probe.naturalHeight || probe.naturalWidth * probe.naturalHeight > 40_000_000) {
      throw new Error('La imagen supera los 40 megapíxeles.');
    }
    if (ticket === uploadId) setDraft({ file, name: file.name }, url);
  } catch (error) {
    if (ticket === uploadId) status.textContent = error.message === 'La imagen supera los 40 megapíxeles.'
      ? error.message : 'No pude abrir esa imagen. Prueba con JPG, PNG o WebP.';
  } finally {
    if (draftUrl !== url) URL.revokeObjectURL(url);
    if (ticket === uploadId) {
      loadingDraft = false;
      $('save').disabled = false;
    }
  }
});

$('example').addEventListener('click', () => {
  uploadId++;
  loadingDraft = false;
  chooser.value = '';
  setDraft(example);
  question.value = example.prompt;
  $('setup-status').textContent = '';
  $('save').disabled = false;
});

$('mission-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (loadingDraft || $('save').disabled) return;
  const status = $('setup-status');
  const value = { ...draft, prompt: question.value.trim() };
  setMission(value);
  $('save').disabled = true;
  try {
    await savedMission(value);
    if (currentView === 'setup') status.textContent = 'Misión guardada. Vuelve al menú y pulsa Jugar cuando estés listo.';
  } catch {
    if (currentView === 'setup') status.textContent = 'Puedes jugar en esta sesión. El navegador no pudo guardar la misión.';
  } finally {
    $('save').disabled = false;
  }
});

setPlayers(1);
setMirror();
for (const id of ['play', 'prepare']) $(id).disabled = true;
savedMission().then((stored) => {
  if (stored) setMission(stored);
}).catch(() => {}).finally(() => {
  for (const id of ['play', 'prepare']) $(id).disabled = false;
});
