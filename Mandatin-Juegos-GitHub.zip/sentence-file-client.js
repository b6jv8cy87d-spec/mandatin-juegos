export function sentenceFileTask(payload) {
  return new Promise((resolve,reject)=>{
    const worker=new Worker(new URL('./sentence-file-worker.js?v=excel1',import.meta.url));
    const finish=(error,value)=>{clearTimeout(timeout);worker.terminate();error?reject(error):resolve(value);};
    const timeout=setTimeout(()=>finish(new Error('El archivo tardó demasiado en abrir. Usa un archivo más pequeño.')),20000);
    worker.onmessage=({data})=>finish(data.error?new Error(data.error):null,data);
    worker.onerror=()=>finish(new Error('No pude abrir el lector de Excel. Recarga el juego e inténtalo de nuevo.'));
    worker.postMessage(payload,payload.buffer?[payload.buffer]:[]);
  });
}
