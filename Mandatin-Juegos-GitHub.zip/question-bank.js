export const BANK_KEY = "mandatin_question_bank_v1";

export function normalizeAnswer(value) {
  return String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es").replace(/[^\p{L}\p{N}\s]/gu, " ").replace(/\s+/g, " ").trim();
}

export function matchesOpenAnswer(input, accepted) {
  const response = normalizeAnswer(input);
  return Boolean(response) && accepted.split(";").some((answer) => normalizeAnswer(answer) === response);
}

export function validQuestion(value) {
  if (!value || typeof value.prompt !== "string" || !value.prompt.trim()) return false;
  if (value.image !== undefined && (typeof value.image !== "string" || !/^data:image\/jpeg;base64,/.test(value.image))) return false;
  if (value.type === "open") return typeof value.answer === "string" && Boolean(value.answer.trim());
  return (value.type === undefined || value.type === "multiple") &&
    Array.isArray(value.options) && value.options.length === 4 &&
    value.options.every((option) => typeof option === "string" && option.trim()) &&
    Number.isInteger(value.correct) && value.correct >= 0 && value.correct < 4;
}

export function loadQuestions(storage = localStorage) {
  try {
    const saved = JSON.parse(storage.getItem(BANK_KEY) || "[]");
    return Array.isArray(saved) ? saved.filter(validQuestion).map((q) => ({
      ...(q.type === "open"
        ? { type: "open", prompt: q.prompt.trim(), answer: q.answer.trim() }
        : { type: "multiple", prompt: q.prompt.trim(), options: q.options.map((option) => option.trim()), correct: q.correct }),
      ...(q.image ? { image: q.image } : {})
    })) : [];
  } catch {
    return [];
  }
}

export function saveQuestions(questions, storage = localStorage) {
  storage.setItem(BANK_KEY, JSON.stringify(questions));
}

export class QuestionDeck {
  constructor(random = Math.random) {
    this.random = random;
    this.remaining = [];
  }

  next(questions) {
    if (!questions.length) return null;
    if (!this.remaining.length) {
      this.remaining = questions.map((_, index) => index);
      for (let i = this.remaining.length - 1; i > 0; i--) {
        const j = Math.floor(this.random() * (i + 1));
        [this.remaining[i], this.remaining[j]] = [this.remaining[j], this.remaining[i]];
      }
    }
    return questions[this.remaining.pop()];
  }

  reset() { this.remaining = []; }
}
