export const WIDTH = 1280;
export const HEIGHT = 720;
const GRAVITY = 790;
const JUMP_PACE = .9;
export const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

export class StarRace {
  constructor(count = 2, random = Math.random) {
    this.random = random;
    this.count = count;
    this.elapsed = 0;
    this.starY = 82;
    this.players = Array.from({ length: count }, (_, index) => {
      const player = { index, hits: 0, active: false, alive: true, spin: 0, spinLength: 0, age: 0 };
      this.spawn(player);
      return player;
    });
  }

  spawn(player) {
    player.x = WIDTH * (player.index + 1) / (this.count + 1);
    player.y = 495;
    player.vx = 0;
    player.vy = player.launchSpeed = -565;
  }

  get starX() {
    return 640 + 435 * Math.sin(this.elapsed * .72);
  }

  bounce(player, pad) {
    player.active = true;
    player.hits++;
    const offset = (player.x - pad.x - pad.w / 2) / Math.max(1, pad.w / 2);
    const direction = Math.abs(offset) >= .48 ? Math.sign(offset) : this.random() < .5 ? -1 : 1;
    let distance = 75 + this.random() * (Math.min(315, 185 + player.hits * 13) - 75);
    if (player.hits >= 4 && this.random() < .18) distance = 25 + this.random() * 35;
    const apex = Math.max(68, 330 - player.hits * 26 + this.random() * 20 - 10);
    const speed = Math.min(940, Math.sqrt(2 * GRAVITY * Math.max(55, player.y - apex)));
    let shift = distance * direction;
    if (player.x + shift < 65 || player.x + shift > WIDTH - 65) shift *= -1;
    const target = clamp(player.x + shift, 65, WIDTH - 65);
    player.vx = (target - player.x) / (2 * speed / GRAVITY);
    player.vy = player.launchSpeed = -speed;
    player.spin = player.spinLength = player.hits >= 2 ? Math.min(.48, .30 + player.hits * .015) : 0;
  }

  step(dt, pads) {
    this.elapsed += dt;
    // Slow the simulation clock for the jumper while preserving the arc.
    const jumpTime = dt * JUMP_PACE;
    for (const player of this.players) {
      if (!player.alive) continue;
      player.age += dt;
      player.spin = Math.max(0, player.spin - jumpTime);
      const pad = pads[player.index];
      for (let remaining = jumpTime; remaining > 0;) {
        const slice = Math.min(remaining, 1 / 120);
        remaining -= slice;
        const previous = player.y;
        player.vy += GRAVITY * slice;
        player.x += player.vx * slice;
        player.y += player.vy * slice;
        if (player.x < 25 || player.x > WIDTH - 25) {
          player.x = clamp(player.x, 25, WIDTH - 25);
          player.vx = player.x === 25 ? Math.abs(player.vx) : -Math.abs(player.vx);
        }
        if (pad && player.vy > 0 && previous <= pad.y + 9 && player.y >= pad.y &&
            player.x + 24 > pad.x && player.x - 24 < pad.x + pad.w) {
          player.y = pad.y;
          this.bounce(player, pad);
        }
        if (player.y > HEIGHT + 56) {
          if (player.active) player.alive = false;
          else this.spawn(player);
          break;
        }
      }
    }
    const winners = this.players.filter(player => player.alive && player.active &&
      player.y <= this.starY + 58 && Math.abs(player.x - this.starX) <= 64);
    if (winners.length) {
      winners.sort((a, b) => Math.abs(a.x - this.starX) - Math.abs(b.x - this.starX));
      return { winner: winners[0].index };
    }
    return this.players.every(player => !player.alive) ? { failed: true } : null;
  }
}
