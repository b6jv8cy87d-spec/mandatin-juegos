import { WIDTH, HEIGHT, clamp, StarRace } from "./engine.js";
import { SAMPLE_W, SAMPLE_H, PAPER_GRACE, PRESETS, PaperDetector, PaperTracker, samplePaper } from "./paper-tracker.js";
import { DwellSelector } from "./dwell-selector.js";

const $ = id => document.getElementById(id);
const game = $("game");
const field = $("field");
const ctx = field.getContext("2d");
const video = $("camera");
const sampleCanvas = document.createElement("canvas");
sampleCanvas.width = SAMPLE_W;
sampleCanvas.height = SAMPLE_H;
const sampleCtx = sampleCanvas.getContext("2d", { willReadFrequently: true });
const screens = ["menu", "editor", "options", "arena", "result"];
const colors = ["#ff6aba", "#66efff"];
const storageKey = "postit-jump-estrella-v1";
const defaultQuestions = [
  { prompt: "¿Qué necesita una planta para crecer?", options: ["Agua y luz", "Piedras y sal", "Solo oscuridad"], correct: 0 },
  { prompt: "¿Cómo se forma una sombra?" },
  { prompt: "¿Qué aprendiste hoy?" }
];

function loadSettings() {
  try { return JSON.parse(localStorage.getItem(storageKey)) ?? {}; }
  catch { return {}; }
}

function cleanQuestions(values) {
  return values.flatMap(value => {
    const text = typeof value === "string" ? value : value?.prompt;
    const prompt = typeof text === "string" ? text.trim().slice(0, 240) : "";
    if (!prompt) return [];
    if (!value.options) return [{ prompt }];
    if (!Array.isArray(value.options) || value.options.length < 2 || value.options.length > 4 ||
        !Number.isInteger(value.correct) || value.correct < 0 || value.correct >= value.options.length) return [];
    const options = value.options.map(option => typeof option === "string" ? option.trim().slice(0, 100) : "");
    if (options.some(option => !option) || new Set(options.map(option => option.toLowerCase())).size !== options.length) return [];
    return [{ prompt, options, correct: value.correct }];
  });
}

const saved = loadSettings();
let questions = Array.isArray(saved.questions) ? cleanQuestions(saved.questions).slice(0, 300) : [...defaultQuestions];
let playerCount = saved.playerCount === 1 ? 1 : 2;
let secondPaper = saved.secondPaper === "fuchsia" ? "fuchsia" : "cyan";
let mirrored = saved.mirrored !== false;
let mode = "demo", state = "menu", selectedPaper = null, stream = null, cameraEpoch = 0;
let race = null, questionIndex = 0, round = 1, countdown = 3, lossReadyAt = null;
let lastSample = -Infinity, lastVideoTime = -1, frameData = null, lastFrame = 0;
let pads = [null, null];
let questionDraftIndex = null;
let answerWinner = null;
const answerDwell = new DwellSelector(2000);
let answersAvailableAt = 0;
let lockedAnswer = false;
const choiceInputs = [...document.querySelectorAll("#choice-fields input[type=text]")];
const correctInputs = [...document.querySelectorAll("#choice-fields input[type=radio]")];
const trackers = [new PaperTracker(), new PaperTracker()];
const detector = new PaperDetector();
const demoPositions = [{ x: 425, y: 570 }, { x: 855, y: 570 }];
const pointerPlayers = new Map();
const keys = new Set();

function save() {
  try {
    localStorage.setItem(storageKey, JSON.stringify({ questions, playerCount, secondPaper, mirrored }));
    return true;
  } catch { return false; }
}

function setText(element, text) {
  if (element.textContent !== text) element.textContent = text;
}

function show(next) {
  state = next;
  const screen = ["setup", "countdown", "playing", "paused", "signal"].includes(next) ? "arena" : next;
  game.dataset.screen = screen;
  for (const id of screens) $(id).hidden = id !== screen;
  $("setup").hidden = next !== "setup";
  $("hud").hidden = !["countdown", "playing", "paused", "signal"].includes(next);
  $("overlay").hidden = !["countdown", "paused", "signal"].includes(next);
  $("pause-actions").hidden = next !== "paused";
  $("recalibrate").hidden = next !== "signal";
  $("pause").disabled = next !== "playing";
  $("pick-two").hidden = playerCount === 1;
  video.hidden = !stream || (screen !== "arena" && !(screen === "result" && answerWinner !== null));
  if (screen !== "result") resetAnswerCursor();
  if (screen !== "arena") pointerPlayers.clear();
  if (screen === "menu") {
    $("one").setAttribute("aria-pressed", String(playerCount === 1));
    $("two").setAttribute("aria-pressed", String(playerCount === 2));
    setText($("questions"), `Preparar preguntas (${questions.length})`);
  }
}

function stopCamera() {
  cameraEpoch++;
  stream?.getTracks().forEach(track => track.stop());
  stream = null;
  video.srcObject = null;
  video.hidden = true;
  frameData = null;
  lastVideoTime = -1;
}

function toMenu() {
  stopCamera();
  setText($("menu-message"), "");
  show("menu");
}

function renderBank() {
  const list = $("question-list");
  list.replaceChildren();
  questions.forEach((question, index) => {
    const item = document.createElement("li");
    item.append(document.createTextNode(`${question.prompt}${question.options ? " · Alternativas" : ""}`));
    const edit = document.createElement("button");
    edit.type = "button";
    edit.textContent = "Editar";
    edit.setAttribute("aria-label", `Editar pregunta ${index + 1}`);
    edit.addEventListener("click", () => openChoiceEditor(index));
    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Quitar";
    remove.setAttribute("aria-label", `Quitar pregunta ${index + 1}`);
    remove.addEventListener("click", () => {
      questions.splice(index, 1);
      setText($("editor-message"), save() ? "Pregunta quitada." : "Cambio aplicado en esta sesión.");
      renderBank();
    });
    item.append(edit, remove);
    list.append(item);
  });
  $("export-bank").disabled = !questions.length;
}

function openChoiceEditor(index = null) {
  questionDraftIndex = index;
  const question = questions[index];
  $("choice-prompt").value = question?.prompt ?? "";
  choiceInputs.forEach((input, i) => { input.value = question?.options?.[i] ?? ""; });
  correctInputs[question?.correct ?? 0].checked = true;
  setText($("choice-message"), "");
  $("choice-editor").showModal();
}

$("add-choices").addEventListener("click", () => openChoiceEditor());
$("cancel-choices").addEventListener("click", () => $("choice-editor").close());
$("choice-form").addEventListener("submit", event => {
  event.preventDefault();
  const prompt = $("choice-prompt").value.trim();
  const fields = choiceInputs.map(input => input.value.trim());
  const selected = correctInputs.findIndex(input => input.checked);
  const options = fields.filter(Boolean);
  const correct = fields.slice(0, selected).filter(Boolean).length;
  if (!prompt || (options.length && (options.length < 2 || !fields[selected]))) {
    setText($("choice-message"), "Escribe la pregunta y al menos dos alternativas, y marca una de ellas como correcta.");
    return;
  }
  const [question] = cleanQuestions([options.length ? { prompt, options, correct } : { prompt }]);
  if (!question) {
    setText($("choice-message"), "Escribe alternativas distintas.");
    return;
  }
  if (questionDraftIndex === null) {
    if (questions.length >= 300) {
      setText($("choice-message"), "El banco admite hasta 300 preguntas.");
      return;
    }
    questions.push(question);
  } else questions[questionDraftIndex] = question;
  setText($("editor-message"), save() ? "Pregunta guardada." : "Pregunta actualizada en esta sesión.");
  $("choice-editor").close();
  renderBank();
});

function editBank(message = "") {
  show("editor");
  setText($("editor-message"), message);
  renderBank();
}

$("question-form").addEventListener("submit", event => {
  event.preventDefault();
  const entries = cleanQuestions($("question-input").value.split(/\r?\n/));
  const room = 300 - questions.length;
  if (!entries.length || !room) {
    setText($("editor-message"), room ? "Escribe al menos una pregunta." : "El banco admite hasta 300 preguntas.");
    return;
  }
  questions.push(...entries.slice(0, room));
  $("question-input").value = "";
  setText($("editor-message"), save() ? `${Math.min(entries.length, room)} preguntas guardadas.` : "Preguntas añadidas en esta sesión.");
  renderBank();
});
$("export-bank").addEventListener("click", () => {
  const data = questions.map(question => question.options ? question : question.prompt);
  const file = new Blob([JSON.stringify({ questions: data }, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(file);
  const link = document.createElement("a");
  link.href = url;
  link.download = "preguntas.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
$("import-bank").addEventListener("change", async event => {
  const file = event.target.files?.[0];
  event.target.value = "";
  if (!file) return;
  try {
    if (file.size > 1024 * 1024) throw new Error();
    const data = JSON.parse(await file.text());
    const values = Array.isArray(data) ? data : data.questions;
    if (!Array.isArray(values)) throw new Error();
    const imported = cleanQuestions(values);
    if (!imported.length) throw new Error();
    const previousCount = questions.length;
    questions = [...new Map([...questions, ...imported].map(question => [JSON.stringify(question), question])).values()].slice(0, 300);
    const stored = save();
    setText($("editor-message"), `${questions.length - previousCount} preguntas añadidas${stored ? "." : " en esta sesión."}`);
    renderBank();
  } catch {
    setText($("editor-message"), "Elige un banco de preguntas JSON válido.");
  }
});

$("one").addEventListener("click", () => { playerCount = 1; save(); show("menu"); });
$("two").addEventListener("click", () => { playerCount = 2; save(); show("menu"); });
$("questions").addEventListener("click", () => editBank());
$("settings").addEventListener("click", () => show("options"));
for (const button of document.querySelectorAll(".menu-back")) button.addEventListener("click", toMenu);
$("paper-two").value = secondPaper;
$("paper-two").addEventListener("change", event => { secondPaper = event.target.value; save(); });
$("mirror").checked = mirrored;
$("mirror").addEventListener("change", event => {
  mirrored = event.target.checked;
  video.classList.toggle("mirrored", mirrored);
  save();
});
$("fullscreen").addEventListener("click", async () => {
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
  } catch { setText($("settings-message"), "La pantalla completa no está disponible en este navegador."); }
});

async function openCamera(deviceId = "") {
  stopCamera();
  const epoch = cameraEpoch;
  resetTracking();
  setText($("setup-message"), "Abriendo la cámara…");
  $("retry-camera").hidden = true;
  $("camera-select").disabled = true;
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Abre el juego desde un enlace HTTPS para usar la cámara.");
    const candidate = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 30, max: 30 },
        ...(deviceId ? { deviceId: { exact: deviceId } } : { facingMode: { ideal: "user" } })
      }
    });
    if (epoch !== cameraEpoch) {
      candidate.getTracks().forEach(track => track.stop());
      return;
    }
    stream = candidate;
    video.srcObject = stream;
    video.classList.toggle("mirrored", mirrored);
    await video.play();
    if (epoch !== cameraEpoch) return;
    video.hidden = false;
    setText($("setup-message"), "Muestra los papeles completos y elige cada uno.");
    const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
    if (epoch !== cameraEpoch) return;
    const actual = stream.getVideoTracks()[0]?.getSettings().deviceId;
    const list = $("camera-select");
    list.replaceChildren(new Option("Cámara predeterminada", ""));
    for (const device of devices.filter(item => item.kind === "videoinput" && item.deviceId)) {
      list.add(new Option(device.label || `Cámara ${list.length}`, device.deviceId));
    }
    list.value = [...list.options].some(option => option.value === actual) ? actual : "";
  } catch (error) {
    if (epoch === cameraEpoch) {
      stream?.getTracks().forEach(track => track.stop());
      stream = null;
      video.srcObject = null;
      video.hidden = true;
      $("retry-camera").hidden = false;
      setText($("setup-message"), error.message.includes("HTTPS") ? error.message :
        "No se pudo abrir la cámara. Revisa el permiso, elige otra cámara o vuelve al menú para probar el modo demo.");
    }
  } finally {
    if (epoch === cameraEpoch) $("camera-select").disabled = false;
  }
}

function resetTracking() {
  trackers.forEach(tracker => tracker.reset());
  pads = [null, null];
  selectedPaper = null;
  frameData = null;
  lastSample = -Infinity;
  updatePaperButtons(performance.now());
}

function startSession(control) {
  if (!questions.length) return editBank("Añade una pregunta para comenzar.");
  questionIndex = 0;
  round = 1;
  race = null;
  mode = control;
  if (mode === "camera") {
    show("setup");
    openCamera();
  } else startRound();
}

$("camera-mode").addEventListener("click", () => startSession("camera"));
$("demo").addEventListener("click", () => startSession("demo"));
$("camera-select").addEventListener("change", event => openCamera(event.target.value));
$("retry-camera").addEventListener("click", () => openCamera($("camera-select").value));

function choosePaper(index) {
  if (!frameData) return;
  selectedPaper = index;
  const color = index === 0 || secondPaper === "fuchsia" ? "fucsia" : "cian";
  setText($("setup-message"), `Toca el centro del papel ${color} de P${index + 1} en la imagen.`);
  updatePaperButtons(performance.now());
}
$("pick-one").addEventListener("click", () => choosePaper(0));
$("pick-two").addEventListener("click", () => choosePaper(1));

function startRound(seconds = 3, preserve = false) {
  if (!preserve) race = new StarRace(playerCount);
  countdown = seconds;
  lossReadyAt = null;
  setText($("turn"), `${playerCount}J · Turno ${round}`);
  setText($("question-number"), `Pregunta ${questionIndex + 1} / ${questions.length}`);
  setText($("timer"), `${race.elapsed.toFixed(1)} s`);
  setText($("overlay-title"), String(seconds));
  setText($("overlay-message"), mode === "demo" ?
    "P1 usa el mouse o un dedo. P2 usa las flechas o un segundo dedo." : "Prepara los post-it.");
  show("countdown");
}

$("start").addEventListener("click", () => {
  if (selectedPaper !== null || !trackers.slice(0, playerCount).every(tracker => tracker.ready(performance.now()))) return;
  startRound(3, Boolean(race));
});
$("pause").addEventListener("click", () => {
  if (state !== "playing") return;
  setText($("overlay-title"), "EN PAUSA");
  setText($("overlay-message"), "Continúa cuando estén listos.");
  show("paused");
});
$("resume").addEventListener("click", () => startRound(3, true));
$("recalibrate").addEventListener("click", () => {
  resetTracking();
  setText($("setup-message"), "Vuelve a elegir los papeles para retomar el turno.");
  show("setup");
  if (!stream?.getVideoTracks().some(track => track.readyState === "live")) openCamera($("camera-select").value);
});

function showResult(outcome) {
  const won = !outcome.failed;
  const question = won ? questions[questionIndex] : null;
  answerWinner = question?.options ? outcome.winner : null;
  lockedAnswer = false;
  resetAnswerCursor();
  answersAvailableAt = performance.now() + 700;
  $("result").dataset.won = String(won);
  setText($("result-title"), won ? "PREGUNTA DE LA ESTRELLA" : "¡OTRO SALTO!");
  setText($("result-time"), won ? `P${outcome.winner + 1} alcanzó la estrella · ${race.elapsed.toFixed(1)} s` : "La estrella sigue esperando");
  setText($("result-question"), question?.prompt ?? "");
  $("result-question").hidden = !won;
  $("answer-options").replaceChildren();
  $("answer-options").hidden = !question?.options;
  $("next").hidden = Boolean(question?.options);
  if (question?.options) {
    question.options.forEach((option, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.answer = String(index);
      button.textContent = `${String.fromCharCode(65 + index)}. ${option}`;
      button.addEventListener("click", () => selectAnswer(question, index, button));
      $("answer-options").append(button);
    });
    setText($("result-note"), mode === "camera" ?
      `P${answerWinner + 1}: apunta con el post-it y mantén el cursor 2 segundos.${playerCount === 2 ? " El otro jugador puede bajar su papel." : ""}` :
      "Toca o haz clic en una alternativa.");
  } else {
    setText($("result-note"), won ?
      "Responde en voz alta. El profesor inicia el siguiente turno." :
      "Conservas la misma pregunta en el próximo intento.");
  }
  setText($("next"), won ? "Siguiente turno" : "Repetir desafío");
  show("result");
}

function selectAnswer(question, index, button) {
  if (state !== "result" || lockedAnswer) return;
  resetAnswerCursor();
  if (index !== question.correct) {
    button.classList.add("wrong");
    button.disabled = true;
    setText($("result-note"), "Prueba con otra alternativa.");
    return;
  }
  lockedAnswer = true;
  button.classList.add("correct");
  for (const option of $("answer-options").children) option.disabled = true;
  $("next").hidden = false;
  answersAvailableAt = performance.now() + 650;
  setText($("result-note"), mode === "camera" ?
    "¡Correcto! Apunta a «Siguiente turno» para continuar." : "¡Correcto!");
}

function resetAnswerCursor() {
  answerDwell.target?.classList.remove("aimed");
  answerDwell.reset();
  $("paper-cursor").hidden = true;
}

function updateAnswerCursor(now) {
  if (now < answersAvailableAt) return;
  const tracker = trackers[answerWinner];
  if (!tracker.visible || !tracker.box || now - tracker.lastSeen > 220) {
    resetAnswerCursor();
    return;
  }
  const { x, y, w, h } = tracker.box;
  const panel = $("result").querySelector(".result-panel").getBoundingClientRect();
  const aimX = clamp(((x + w / 2) / SAMPLE_W - .12) / .76, 0, 1);
  const aimY = clamp(((y + h / 2) / SAMPLE_H - .15) / .70, 0, 1);
  const screenX = panel.left + aimX * panel.width;
  const screenY = panel.top + aimY * panel.height;
  const bounds = game.getBoundingClientRect();
  const cursor = $("paper-cursor");
  cursor.hidden = false;
  cursor.style.left = `${screenX - bounds.left}px`;
  cursor.style.top = `${screenY - bounds.top}px`;
  const target = document.elementFromPoint(screenX, screenY)?.closest("[data-answer]:enabled, #next:not([hidden])") ?? null;
  if (answerDwell.target !== target) {
    answerDwell.target?.classList.remove("aimed");
    target?.classList.add("aimed");
  }
  const { progress, select } = answerDwell.update(target, now);
  cursor.style.setProperty("--progress", `${progress * 360}deg`);
  if (select) target.click();
}

$("next").addEventListener("click", () => {
  if (state !== "result" || $("next").hidden) return;
  if ($("result").dataset.won === "true") {
    questionIndex = (questionIndex + 1) % questions.length;
    round++;
  }
  if (mode === "camera" && !stream) {
    race = null;
    show("setup");
    openCamera($("camera-select").value);
  } else startRound(5);
});

function readCamera(now) {
  if (!stream || video.readyState < 2 || now - lastSample < 40 || video.currentTime === lastVideoTime) return;
  lastSample = now;
  lastVideoTime = video.currentTime;
  const ratio = WIDTH / HEIGHT;
  const sourceW = Math.min(video.videoWidth, video.videoHeight * ratio);
  const sourceH = sourceW / ratio;
  sampleCtx.setTransform(mirrored ? -1 : 1, 0, 0, 1, mirrored ? SAMPLE_W : 0, 0);
  sampleCtx.drawImage(video, (video.videoWidth - sourceW) / 2, (video.videoHeight - sourceH) / 2,
    sourceW, sourceH, 0, 0, SAMPLE_W, SAMPLE_H);
  frameData = sampleCtx.getImageData(0, 0, SAMPLE_W, SAMPLE_H).data;
  if (trackers.some(tracker => tracker.profile)) detector.read(frameData);
  trackers.slice(0, playerCount).forEach((tracker, index) => {
    if (!tracker.profile || (state === "result" && index !== answerWinner)) return;
    const other = trackers[1 - index];
    const reserved = playerCount === 2 && now - other.lastSeen <= PAPER_GRACE ? other.box : null;
    tracker.update(detector.find(tracker.profile), now, reserved);
  });
}

function updatePaperButtons(now) {
  const labels = trackers.slice(0, playerCount).map((tracker, index) => {
    const button = $(index ? "pick-two" : "pick-one");
    button.disabled = !frameData;
    button.setAttribute("aria-pressed", String(selectedPaper === index));
    const ready = tracker.ready(now);
    setText(button, ready ? `P${index + 1} listo ✓` : tracker.anchor ? `Detectando P${index + 1}…` : `Elegir papel P${index + 1}`);
    return ready;
  });
  $("start").disabled = selectedPaper !== null || !labels.every(Boolean);
}

function canvasPoint(event) {
  const rect = field.getBoundingClientRect();
  return { x: clamp((event.clientX - rect.left) * WIDTH / rect.width, 0, WIDTH - 1),
    y: clamp((event.clientY - rect.top) * HEIGHT / rect.height, 0, HEIGHT - 1) };
}

field.addEventListener("pointerdown", event => {
  const point = canvasPoint(event);
  if (state === "setup" && selectedPaper !== null && frameData) {
    const index = selectedPaper;
    const expected = index ? PRESETS[secondPaper] : PRESETS.fuchsia;
    const x = Math.floor(point.x / 4), y = Math.floor(point.y / 4);
    const profile = samplePaper(frameData, x, y, expected);
    if (!profile) {
      setText($("setup-message"), "No se reconoció el color. Toca el centro del papel con buena luz.");
      return;
    }
    trackers[index].select(x, y, profile);
    selectedPaper = null;
    setText($("setup-message"), "Mantén el papel visible hasta que aparezca como listo.");
  }
  if (mode !== "demo" || event.pointerType === "mouse") return;
  const used = new Set(pointerPlayers.values());
  const index = Array.from({ length: playerCount }, (_, i) => i).find(i => !used.has(i));
  if (index === undefined) return;
  pointerPlayers.set(event.pointerId, index);
  field.setPointerCapture(event.pointerId);
  demoPositions[index] = point;
});
field.addEventListener("pointermove", event => {
  if (mode !== "demo") return;
  const index = event.pointerType === "mouse" ? 0 : pointerPlayers.get(event.pointerId);
  if (index !== undefined) demoPositions[index] = canvasPoint(event);
});
for (const event of ["pointerup", "pointercancel", "lostpointercapture"]) {
  field.addEventListener(event, event => pointerPlayers.delete(event.pointerId));
}
document.addEventListener("keydown", event => {
  if (event.target instanceof HTMLTextAreaElement || event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement) return;
  if (game.dataset.screen === "arena" && event.key.startsWith("Arrow")) {
    event.preventDefault();
    keys.add(event.key);
  }
  if (event.repeat) return;
  if (event.key.toLowerCase() === "p") {
    if (state === "playing") $("pause").click();
    else if (state === "paused") $("resume").click();
  }
  if (event.key === "Escape" && state === "playing") $("pause").click();
  if (event.key === "Enter" && state === "result" && event.target === document.body) $("next").click();
});
document.addEventListener("keyup", event => keys.delete(event.key));
window.addEventListener("blur", () => keys.clear());
window.addEventListener("pagehide", () => {
  if (mode === "camera") toMenu();
});

function getPads(dt, now) {
  if (mode === "camera") return trackers.map(tracker => tracker.platform(now));
  const p2 = demoPositions[1];
  p2.x += (Number(keys.has("ArrowRight")) - Number(keys.has("ArrowLeft"))) * 420 * dt;
  p2.y += (Number(keys.has("ArrowDown")) - Number(keys.has("ArrowUp"))) * 420 * dt;
  p2.x = clamp(p2.x, 55, WIDTH - 55);
  p2.y = clamp(p2.y, 135, 635);
  return demoPositions.map(({ x, y }) => ({ x: clamp(x - 55, 0, WIDTH - 110), y: clamp(y, 135, 635), w: 110, h: 80 }));
}

const images = {};
for (const key of ["p1", "p2", "pad1", "pad2", "estrella"]) {
  images[key] = new Image();
  images[key].src = `./assets/${key}.png`;
}
const isReady = image => image.complete && image.naturalWidth > 0;

function drawPlayer(player) {
  const image = images[`p${player.index + 1}`];
  const row = player.spin > 0 ? 3 : !player.active ? 0 : player.vy > 0 ? 2 : 1;
  const progress = row === 3 ? 1 - player.spin / player.spinLength :
    row === 0 ? player.age * 1.5 % 1 : row === 1 ?
      clamp(1 - player.vy / player.launchSpeed, 0, .999) : clamp(player.vy / -player.launchSpeed, 0, .999);
  const frame = Math.min(7, Math.floor(progress * 8));
  if (isReady(image)) ctx.drawImage(image, frame * 112, row * 112, 112, 112, player.x - 56, player.y - 108, 112, 112);
  else {
    ctx.fillStyle = colors[player.index];
    ctx.beginPath();
    ctx.arc(player.x, player.y - 30, 30, 0, Math.PI * 2);
    ctx.fill();
  }
}

function render() {
  ctx.clearRect(0, 0, WIDTH, HEIGHT);
  if (state === "setup") {
    if (!frameData) return;
    for (const [index, tracker] of trackers.slice(0, playerCount).entries()) {
      const pad = tracker.platform(performance.now());
      if (!pad) continue;
      ctx.strokeStyle = colors[index];
      ctx.lineWidth = 4;
      ctx.strokeRect(pad.x, pad.y, pad.w, pad.h);
      ctx.font = "bold 20px system-ui";
      ctx.fillStyle = colors[index];
      ctx.fillText(`P${index + 1}`, pad.x, pad.y - 8);
    }
    return;
  }
  if (!race) return;
  const star = images.estrella;
  if (isReady(star)) ctx.drawImage(star, Math.floor(race.elapsed * 18) % 12 * 96, 0, 96, 96, race.starX - 48, race.starY - 48, 96, 96);
  else {
    ctx.font = "64px system-ui";
    ctx.fillStyle = "#ffdb62";
    ctx.fillText("★", race.starX - 30, race.starY + 20);
  }
  for (const player of race.players) {
    if (!player.alive) continue;
    const pad = pads[player.index];
    if (pad && mode === "demo") {
      const padImage = images[`pad${player.index + 1}`];
      if (isReady(padImage)) ctx.drawImage(padImage, pad.x - 8, pad.y - 2, pad.w + 16, 40);
      else {
        ctx.fillStyle = colors[player.index];
        ctx.fillRect(pad.x, pad.y, pad.w, 16);
      }
    }
    drawPlayer(player);
  }
}

function update(dt, now) {
  if (state === "setup") {
    updatePaperButtons(now);
    return;
  }
  if (!["countdown", "playing", "signal", "paused"].includes(state)) return;
  pads = getPads(dt, now);
  if (state === "paused") return;
  const allTracked = race.players.every((player, index) => !player.alive || pads[index]);
  if (!allTracked) {
    lossReadyAt = null;
    if (state !== "signal") show("signal");
    setText($("overlay-title"), "PAPEL FUERA DE CÁMARA");
    setText($("overlay-message"), "Muestra el papel completo para retomar el turno.");
    return;
  }
  if (state === "signal") {
    lossReadyAt ??= now + 2000;
    setText($("overlay-title"), String(Math.max(1, Math.ceil((lossReadyAt - now) / 1000))));
    setText($("overlay-message"), "Papel detectado. Retomamos el turno.");
    if (now >= lossReadyAt) {
      show(countdown > 0 ? "countdown" : "playing");
      if (countdown > 0) setText($("overlay-message"), "Prepara los post-it.");
    }
    return;
  }
  if (state === "countdown") {
    countdown -= dt;
    if (countdown <= 0) show("playing");
    else setText($("overlay-title"), String(Math.ceil(countdown)));
    return;
  }
  const outcome = race.step(dt, pads);
  setText($("timer"), `${race.elapsed.toFixed(1)} s`);
  if (outcome) showResult(outcome);
}

function tick(now) {
  const dt = lastFrame ? Math.min(.05, (now - lastFrame) / 1000) : 0;
  lastFrame = now;
  if (game.dataset.screen === "arena") {
    if (mode === "camera") readCamera(now);
    update(dt, now);
    if (game.dataset.screen === "arena") render();
  } else if (state === "result" && mode === "camera" && answerWinner !== null && stream) {
    readCamera(now);
    updateAnswerCursor(now);
  }
  requestAnimationFrame(tick);
}

show("menu");
requestAnimationFrame(tick);
