export function formatTime(ms) {
  const seconds = Math.floor(Math.max(0, ms) / 1000);
  return `${String(Math.floor(seconds / 60)).padStart(2,'0')}:${String(seconds % 60).padStart(2,'0')}`;
}

export class SentenceChallenge {
  constructor() { this.reset(); }
  reset() { this.results=[]; this.total=0; this.visits=0; this.running=false; this.newRound(3); this.running=false; }
  newRound(words) {
    this.words=words; this.elapsed=0; this.phase='waiting'; this.phaseTime=0; this.running=true;
    this.nextVisit=15000;
  }
  get approachDuration() { return Math.max(1100,2200-this.visits*100); }
  get returnDuration() { return Math.max(1000,1800-this.visits*80); }
  get cooldown() { return 15000; }
  step(ms, active, eligible, enemyEnabled=true) {
    if (!this.running || !active || !Number.isFinite(ms) || ms<0) return [];
    this.elapsed+=ms; this.total+=ms;
    if (!enemyEnabled) { this.phase='waiting'; this.nextVisit=this.elapsed+this.cooldown; return []; }
    this.phaseTime+=ms;
    if (this.phase==='waiting' && this.elapsed>=this.nextVisit) {
      this.visits++; this.phase='approach'; this.phaseTime=0; this.canSteal=eligible;
      return [eligible?'approach':'flyby'];
    }
    if (this.phase==='approach' && this.phaseTime>=this.approachDuration) {
      this.phase='return'; this.phaseTime=0; return [eligible && this.canSteal?'steal':'pass'];
    }
    if (this.phase==='return' && this.phaseTime>=this.returnDuration) {
      this.phase='waiting'; this.phaseTime=0; this.nextVisit=this.elapsed+this.cooldown; return ['returned'];
    }
    return [];
  }
  complete(sentence) {
    if (!this.running) return null;
    this.running=false; this.phase='waiting';
    const result={sentence,ms:this.elapsed};this.results.push(result);return result;
  }
}
