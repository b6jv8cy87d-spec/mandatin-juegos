export const ENERGY_PER_QUESTION = 3;

// This clock advances only with gameplay: pause, questions and camera loss freeze it.
export class OrbitEncounter {
  constructor() { this.reset(); }
  reset() {
    this.phase = 'flight'; this.elapsed = 0; this.questions = 0;
    this.round = 0; this.flyby = null; this.nextFlyby = 3500; this.passes = 0;
    this.shotTimer = 0; this.rockTimer = 0; this.hits = 0;
  }
  answered() {
    this.questions++;
    return true;
  }
  start() {
    if (this.phase !== 'flight') return false;
    this.round++; this.phase = 'arrival'; this.elapsed = 0;
    this.shotTimer = 0; this.rockTimer = 0; this.hits = 0; this.flyby = null;
    return true;
  }
  get battling() { return this.phase !== 'flight'; }
  get duration() { return Math.min(26000, 16000 + this.round * 2000); }
  step(ms, gameTime) {
    this.elapsed += ms;
    const events = [];
    if (this.phase === 'flight') {
      if (this.flyby) {
        this.flyby.progress += ms / 32000;
        if (this.flyby.progress >= 1) this.flyby = null;
      }
      if (!this.flyby && gameTime >= this.nextFlyby) {
        this.flyby = { progress: 0, reverse: this.passes++ % 2 === 1 };
        this.nextFlyby = gameTime + 46000; events.push('flyby');
      }
    } else if (this.phase === 'arrival' && this.elapsed >= 2800) {
      this.phase = 'battle'; this.elapsed = 0; events.push('battleStart');
    } else if (this.phase === 'battle') {
      if (this.elapsed >= this.duration) {
        this.phase = 'departure'; this.elapsed = 0; events.push('battleWon');
      } else {
        this.shotTimer += ms; this.rockTimer += ms;
        if (this.shotTimer >= Math.max(650, 1500 - this.round * 110)) {
          this.shotTimer = 0; events.push('shot');
        }
        if (this.rockTimer >= Math.max(1800, 3200 - this.round * 180)) {
          this.rockTimer = 0; events.push('rock');
        }
      }
    } else if (this.phase === 'departure' && this.elapsed >= 2400) {
      this.phase = 'flight'; this.elapsed = 0;
      this.nextFlyby = gameTime + 5000; events.push('flightResumed');
    }
    return events;
  }
}
