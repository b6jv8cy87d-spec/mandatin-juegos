import { FingerFilter } from './finger-filter.js';
// MediaPipe runs in a worker so inference cannot freeze the game animation.
export class HandTracker {
  constructor(videoElement, overlayCanvas) {
    this.video = videoElement;
    this.overlayCanvas = overlayCanvas;
    this.overlayCtx = overlayCanvas.getContext("2d");
    this.worker = null;
    this.filter = new FingerFilter();
    this.streamEpoch = 0;
    this.baseDetectionIntervalMs = 70;
    this.processingMs = 0;
    this.workerReady = false;
    this.detectionInFlight = false;
    this.lastDetectionRequestedAt = 0;
    this.detectionIntervalMs = 70;
    this.lastVideoTime = -1;
    this.lastResultAt = 0;
    this.lastOverlayResultAt = 0;
    this.overlayHasHand = false;
    this.latestCoords = null;
    this.latestLandmarks = null;
    this.handLandmarker = null;
    this.stream = null;
    this.cameraDeviceId = "";
    this.cameraQuality = "auto";
    this.isInitialized = false;
    this.isTracking = false;
    this.INDEX_FINGER_TIP = 8;
    this.HAND_CONNECTIONS = [
      [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8],
      [9, 10], [10, 11], [11, 12], [13, 14], [14, 15], [15, 16],
      [0, 17], [17, 18], [18, 19], [19, 20], [5, 9], [9, 13], [13, 17]
    ];
  }

  async initialize(statusCallback = () => {}) {
    statusCallback("Preparando seguimiento en segundo plano...");
    if (typeof Worker !== "undefined" && typeof createImageBitmap === "function") {
      try {
        await this.initializeWorker(statusCallback);
        this.isInitialized = true;
        statusCallback("Modelo listo — animación optimizada");
        return true;
      } catch (error) {
        console.warn("Worker unavailable, using main thread fallback:", error);
        this.worker?.terminate();
        this.worker = null;
        this.workerReady = false;
      }
    }

    statusCallback("Cargando modelo de manos...");
    const { FilesetResolver, HandLandmarker } = await import(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8/vision_bundle.mjs"
    );
    const vision = await FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8/wasm"
    );
    let lastError;
    for (const delegate of ["GPU", "CPU"]) {
      try {
        this.handLandmarker = await HandLandmarker.createFromOptions(vision, {
          baseOptions: {
            modelAssetPath: "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
            delegate
          },
          runningMode: "VIDEO",
          numHands: 1,
          minHandDetectionConfidence: 0.45,
          minHandPresenceConfidence: 0.45,
          minTrackingConfidence: 0.45
        });
        break;
      } catch (error) { lastError = error; }
    }
    if (!this.handLandmarker) throw lastError;
    this.isInitialized = true;
    statusCallback("Modelo listo");
    return true;
  }

  initializeWorker(statusCallback) {
    return new Promise((resolve, reject) => {
      this.worker = new Worker("./hand-tracking-worker.js");
      const timeout = window.setTimeout(() => reject(new Error("El worker tardó demasiado en iniciar.")), 30000);
      this.worker.onmessage = ({ data }) => {
        if (data.type === "READY") {
          window.clearTimeout(timeout);
          this.workerReady = true;
          statusCallback(`Modelo listo (${data.delegate})`);
          resolve();
        } else if (data.type === "INIT_ERROR") {
          window.clearTimeout(timeout);
          reject(new Error(data.message));
        } else if (data.type === "RESULT") {
          if (data.epoch !== this.streamEpoch) return;
          this.detectionInFlight = false;
          const now = performance.now();
          this.tuneDetectionRate(now-data.timestamp);
          this.acceptResult(data.tracking ? data.landmarks : null, now);
        } else if (data.type === "ERROR") {
          if (data.epoch !== this.streamEpoch) return;
          this.detectionInFlight = false;
          this.acceptResult(null, performance.now());
          console.warn("Hand tracking frame failed:", data.message);
        }
      };
      this.worker.onerror = (error) => {
        window.clearTimeout(timeout);
        reject(error);
      };
      this.worker.postMessage({ type: "INIT" });
    });
  }

  async startCamera(deviceId = "", quality = "auto") {
    if (this.stream && this.cameraDeviceId === deviceId && this.cameraQuality === quality) return this.stream;
    if (this.stream) this.stopStream();
    const profiles = {
      light: { width: 320, height: 240, frameRate: 15, detectionIntervalMs: 105 },
      auto: { width: 480, height: 360, frameRate: 24, detectionIntervalMs: 70 },
      high: { width: 640, height: 480, frameRate: 30, detectionIntervalMs: 55 }
    };
    const profile = profiles[quality] || profiles.auto;
    this.baseDetectionIntervalMs = profile.detectionIntervalMs;
    this.detectionIntervalMs = profile.detectionIntervalMs;
    this.processingMs = 0;
    this.overlayCanvas.width = profile.width;
    this.overlayCanvas.height = profile.height;
    const constraints = {
      video: {
        ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
        width: { ideal: profile.width },
        height: { ideal: profile.height },
        frameRate: { ideal: profile.frameRate, max: profile.frameRate }
      },
      audio: false
    };
    try {
      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.cameraDeviceId = deviceId;
      this.cameraQuality = quality;
      this.video.srcObject = this.stream;
      return new Promise((resolve) => {
        const ready = () => {
          this.video.onloadedmetadata = null;
          this.video.play().then(() => resolve(this.stream)).catch(() => resolve(this.stream));
        };
        if (this.video.readyState >= 1) ready();
        else this.video.onloadedmetadata = ready;
      });
    } catch (error) {
      console.error("Error accessing webcam:", error);
      throw error;
    }
  }

  stopStream() {
    this.streamEpoch++;
    this.filter.reset();
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    if (this.video) this.video.srcObject = null;
    this.isTracking = false;
    this.latestCoords = null;
    this.latestLandmarks = null;
    this.lastVideoTime = -1;
    this.lastOverlayResultAt = 0;
    this.overlayHasHand = false;
    this.detectionInFlight = false;
    this.clearOverlay();
  }

  stopCamera() {
    this.stopStream();
    this.worker?.terminate();
    this.worker = null;
    this.workerReady = false;
    this.handLandmarker?.close();
    this.handLandmarker = null;
    this.isInitialized = false;
  }

  clearOverlay() {
    this.overlayCtx.clearRect(0, 0, this.overlayCanvas.width, this.overlayCanvas.height);
  }

  detectFrame() {
    if (!this.isInitialized || !this.video.srcObject || this.video.paused) {
      this.isTracking = false;
      this.latestCoords = null;
      this.latestLandmarks = null;
      if (this.overlayHasHand) {
        this.clearOverlay();
        this.lastOverlayResultAt = 0;
        this.overlayHasHand = false;
      }
      return null;
    }

    const now = performance.now();
    const videoTime = this.video.currentTime;
    if (this.workerReady) {
      if (!this.detectionInFlight && videoTime !== this.lastVideoTime && now - this.lastDetectionRequestedAt >= this.detectionIntervalMs) {
        this.lastVideoTime = videoTime;
        this.lastDetectionRequestedAt = now;
        this.detectionInFlight = true;
        const epoch = this.streamEpoch;
        createImageBitmap(this.video).then((bitmap) => {
          if (this.workerReady && epoch === this.streamEpoch) this.worker.postMessage({ type: "DETECT", bitmap, timestamp: now, epoch }, [bitmap]);
          else { bitmap.close(); if(epoch === this.streamEpoch) this.detectionInFlight = false; }
        }).catch(() => { if(epoch === this.streamEpoch) this.detectionInFlight = false; });
      }
      if (now - this.lastResultAt > 300) { this.isTracking = false; this.filter.reset(); }
      if (this.lastResultAt !== this.lastOverlayResultAt || (this.overlayHasHand && !this.isTracking)) {
        this.clearOverlay();
        if (this.isTracking && this.latestLandmarks) this.drawHandOverlay(this.latestLandmarks);
        this.lastOverlayResultAt = this.lastResultAt;
        this.overlayHasHand = this.isTracking;
      }
      return this.isTracking ? this.latestCoords : null;
    }

    return this.detectFrameOnMainThread(now);
  }

  detectFrameOnMainThread(now) {
    if (this.video.currentTime === this.lastVideoTime || now - this.lastDetectionRequestedAt < this.detectionIntervalMs) {
      if (now - this.lastResultAt > 300) { this.isTracking = false; this.filter.reset(); }
      return this.isTracking ? this.latestCoords : null;
    }
    this.lastVideoTime = this.video.currentTime;
    this.lastDetectionRequestedAt = now;
    try {
      const result = this.handLandmarker.detectForVideo(this.video, now);
      this.tuneDetectionRate(performance.now()-now);
      this.acceptResult(result?.landmarks?.[0], performance.now());
      this.clearOverlay();
      if(this.latestLandmarks) this.drawHandOverlay(this.latestLandmarks);
      return this.latestCoords;
    } catch(error) {
      this.acceptResult(null, performance.now());
      return null;
    }
  }

  tuneDetectionRate(duration) {
    if(!Number.isFinite(duration))return;
    this.processingMs=this.processingMs ? this.processingMs*.85+duration*.15 : duration;
    // Leave time for rendering on slower devices; never queue inference frames.
    this.detectionIntervalMs=Math.min(160,Math.max(this.baseDetectionIntervalMs,this.processingMs*1.35));
  }

  acceptResult(landmarks, now) {
    this.lastResultAt=now;
    const tip=landmarks?.[this.INDEX_FINGER_TIP];
    this.latestCoords=this.filter.update(tip ? {x:1-tip.x,y:tip.y} : null,now);
    this.isTracking=!!this.latestCoords;
    this.latestLandmarks=this.isTracking ? landmarks : null;
  }

  drawHandOverlay(landmarks) {
    const width = this.overlayCanvas.width;
    const height = this.overlayCanvas.height;
    this.overlayCtx.strokeStyle = "rgba(0, 240, 255, 0.4)";
    this.overlayCtx.lineWidth = 2.5;
    for (const [a, b] of this.HAND_CONNECTIONS) {
      const p1 = landmarks[a];
      const p2 = landmarks[b];
      this.overlayCtx.beginPath();
      this.overlayCtx.moveTo(p1.x * width, p1.y * height);
      this.overlayCtx.lineTo(p2.x * width, p2.y * height);
      this.overlayCtx.stroke();
    }
    for (let i = 0; i < landmarks.length; i += 1) {
      const point = landmarks[i];
      const cx = point.x * width;
      const cy = point.y * height;
      this.overlayCtx.beginPath();
      this.overlayCtx.arc(cx, cy, i === this.INDEX_FINGER_TIP ? 7 : 4, 0, 2 * Math.PI);
      this.overlayCtx.fillStyle = i === this.INDEX_FINGER_TIP ? "#39ff14" : "#00f0ff";
      this.overlayCtx.shadowColor = i === this.INDEX_FINGER_TIP ? "#39ff14" : "transparent";
      this.overlayCtx.shadowBlur = i === this.INDEX_FINGER_TIP ? 10 : 0;
      this.overlayCtx.fill();
    }
    this.overlayCtx.shadowBlur = 0;
  }
}
