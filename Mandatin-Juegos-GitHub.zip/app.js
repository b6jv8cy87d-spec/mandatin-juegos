import { DwellSelector } from './dwell-selector.js';
import { HandTracker } from "./handTracking.js";
import { Game } from "./game.js";
import { QuestionDeck, loadQuestions, matchesOpenAnswer, saveQuestions } from "./question-bank.js";

// DOM Element references
const videoElement = document.getElementById("webcamVideo");
const webcamOverlayCanvas = document.getElementById("webcamOverlay");
const gameCanvas = document.getElementById("gameCanvas");

// Overlays
const loadingOverlay = document.getElementById("loadingOverlay");
const startOverlay = document.getElementById("startOverlay");
const countdownOverlay = document.getElementById("countdownOverlay");
const pauseOverlay = document.getElementById("pauseOverlay");
const trackingLostOverlay = document.getElementById("trackingLostOverlay");
const gameOverOverlay = document.getElementById("gameOverOverlay");
const bankOverlay = document.getElementById("bankOverlay");
const questionOverlay = document.getElementById("questionOverlay");
const cameraSetupOverlay = document.getElementById("cameraSetupOverlay");
const cameraSelect = document.getElementById("cameraSelect");
const qualitySelect = document.getElementById("qualitySelect");
const testCameraBtn = document.getElementById("testCameraBtn");
const confirmCameraBtn = document.getElementById("confirmCameraBtn");
const backFromCameraBtn = document.getElementById("backFromCameraBtn");
const cameraSetupStatus = document.getElementById("cameraSetupStatus");
const cameraPreviewPlaceholder = document.getElementById("cameraPreviewPlaceholder");
const setupVideo = document.getElementById("setupVideo");
const changeModeBtn = document.getElementById("changeModeBtn");

// Texts & values
const loadingStatusText = document.getElementById("loadingStatus");
const countdownText = document.getElementById("countdownText");
const scoreValText = document.getElementById("scoreVal");
const levelValText = document.getElementById("levelVal");
const highScoreValText = document.getElementById("highScoreVal");
const finalScoreValText = document.getElementById("finalScoreVal");
const finalLevelValText = document.getElementById("finalLevelVal");
const newHighScoreBadge = document.getElementById("newHighScoreBadge");
const fpsValText = document.getElementById("fpsVal");
const questionProgress = document.getElementById("questionProgress");
const questionProgressGroup = document.getElementById("questionProgressGroup");

// Status indicators
const trackingStatusDot = document.getElementById("trackingStatusDot");
const trackingStatusText = document.getElementById("trackingStatusText");
const camIndicator = document.getElementById("camIndicator");
const fpsCounterContainer = document.getElementById("fpsCounter");

// Buttons
const startGameBtn = document.getElementById("startGameBtn");
const resumeGameBtn = document.getElementById("resumeGameBtn");
const restartGameBtn = document.getElementById("restartGameBtn");
const pauseToggleBtn = document.getElementById("pauseToggleBtn");
const muteToggleBtn = document.getElementById("muteToggleBtn");
const cameraToggleBtn = document.getElementById("cameraToggleBtn");
const debugToggleBtn = document.getElementById("debugToggleBtn");
const webcamPanel = document.getElementById("webcamPanel");
const openBankBtn = document.getElementById("openBankBtn");
const closeBankBtn = document.getElementById("closeBankBtn");
const bankDoneBtn = document.getElementById("bankDoneBtn");
const bankCount = document.getElementById("bankCount");
const bankListCount = document.getElementById("bankListCount");
const questionForm = document.getElementById("questionForm");
const questionPrompt = document.getElementById("questionPrompt");
const correctOption = document.getElementById("correctOption");
const questionList = document.getElementById("questionList");
const activeQuestion = document.getElementById("activeQuestion");
const answerOptions = document.getElementById("answerOptions");
const answerFeedback = document.getElementById("answerFeedback");
const optionInputs = [0, 1, 2, 3].map((i) => document.getElementById(`option${i}`));
const questionType = document.getElementById("questionType");
const multipleFields = document.getElementById("multipleFields");
const openFields = document.getElementById("openFields");
const openAnswer = document.getElementById("openAnswer");
const freeModeBtn = document.getElementById("freeModeBtn");
const quizModeBtn = document.getElementById("quizModeBtn");
const questionImage = document.getElementById("questionImage");
const imagePreview = document.getElementById("imagePreview");
const imagePreviewWrap = document.getElementById("imagePreviewWrap");
const removeImageBtn = document.getElementById("removeImageBtn");
const activeQuestionImage = document.getElementById("activeQuestionImage");
const bankError = document.getElementById("bankError");

function compressQuestionImage(file) {
  if (!file.type.startsWith("image/") || file.size > 8 * 1024 * 1024) {
    return Promise.reject(new Error("Elige una imagen de hasta 8 MB."));
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("No pude leer la imagen."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("El navegador no pudo abrir esta imagen. Prueba con JPG o PNG."));
      image.onload = () => {
        const scale = Math.min(1, 960 / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext("2d");
        context.fillStyle = "#fff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        const data = canvas.toDataURL("image/jpeg", 0.76);
        if (data.length > 600000) reject(new Error("La imagen ocupa demasiado espacio. Elige una más simple o pequeña."));
        else resolve(data);
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

// Game state constants
const STATES = {
  LOADING: "LOADING",
  START_SCREEN: "START_SCREEN",
  CAMERA_SETUP: "CAMERA_SETUP",
  BANK: "BANK",
  QUESTION: "QUESTION",
  COUNTDOWN: "COUNTDOWN",
  PLAYING: "PLAYING",
  PAUSED: "PAUSED",
  GAME_OVER: "GAME_OVER"
};

class AppController {
  constructor() {
    this.currentState = STATES.LOADING;
    
    // Instantiate core modules
    this.tracker = new HandTracker(videoElement, webcamOverlayCanvas);
    this.game = new Game(gameCanvas);
    this.questions = loadQuestions();
    this.deck = new QuestionDeck();
    this.editingIndex = -1;
    this.pendingImage = null;
    this.imageRemoved = false;
    this.activeQuiz = null;
    this.quizResolved = false;
    this.playMode = localStorage.getItem("mandatin_play_mode") === "free" ? "free" : "questions";
    this.cameraBusy = false;
    this.dwell = new DwellSelector();
    this.handCursor = document.createElement('div');
    this.handCursor.id='answerHandCursor';
    this.handCursor.hidden=true;
    document.body.append(this.handCursor);
    
    // State timer variables
    this.countdownValue = 3;
    this.countdownTimer = 0;
    
    // Hand tracking helper timers
    this.handLostTime = null;
    this.isTrackingLostOverlayActive = false;
    this.lastTrackingStatus = "red"; // dot status

    // Bind event listeners
    this.setupEventListeners();
    this.renderBank();
    this.renderMode();
  }

  /** Show the editor immediately; load the camera model only at launch. */
  init() {
    this.updateHUD();
    this.transitionToState(STATES.START_SCREEN);
  }

  /**
   * Binds user inputs and click actions
   */
  setupEventListeners() {
    const fullscreenButton = document.getElementById("orbitFullscreenBtn");
    fullscreenButton.addEventListener("click", async () => {
      try {
        if (document.fullscreenElement) await document.exitFullscreen();
        else await document.documentElement.requestFullscreen();
      } catch {
        fullscreenButton.textContent = "Amplía la ventana";
      }
    });
    const startPointerGame = () => {
      if (this.playMode === 'questions' && !this.questions.length) { this.transitionToState(STATES.BANK); return; }
      this.usePointer = true;
      document.getElementById('appContainer').dataset.control = 'pointer';
      this.pointerCoords = { x: .5, y: .5 };
      this.tracker.stopStream();
      setupVideo.srcObject = null;
      cameraPreviewPlaceholder.classList.remove("hidden");
      this.game.initAudio();
      this.startCountdown();
    };
    document.getElementById('pointerPlayBtn').addEventListener('click', startPointerGame);
    document.getElementById('cameraPointerBtn').addEventListener('click', startPointerGame);
    document.getElementById('gameArea').addEventListener('pointermove', (event) => {
      if (!this.usePointer) return;
      const rect = (document.querySelector('#orbitStage canvas') || gameCanvas).getBoundingClientRect();
      this.pointerCoords = { x: Math.max(0,Math.min(1,(event.clientX-rect.left)/rect.width)), y: Math.max(0,Math.min(1,(event.clientY-rect.top)/rect.height)) };
    });
    // Start game button
    startGameBtn.addEventListener("click", () => this.openCameraSetup());
    testCameraBtn.addEventListener("click", () => this.testSelectedCamera());
    confirmCameraBtn.addEventListener("click", () => this.handleRequestCameraAndStart());
    backFromCameraBtn.addEventListener("click", () => {
      this.tracker.stopStream();
      setupVideo.srcObject = null;
      cameraPreviewPlaceholder.classList.remove("hidden");
      this.transitionToState(STATES.START_SCREEN);
    });
    changeModeBtn.addEventListener("click", () => {
      this.tracker.stopCamera();
      setupVideo.srcObject = null;
      cameraPreviewPlaceholder.classList.remove("hidden");
      this.transitionToState(STATES.START_SCREEN);
    });
    openBankBtn.addEventListener("click", () => this.transitionToState(STATES.BANK));
    closeBankBtn.addEventListener("click", () => this.transitionToState(STATES.START_SCREEN));
    bankDoneBtn.addEventListener("click", () => this.transitionToState(STATES.START_SCREEN));
    questionForm.addEventListener("submit", (event) => this.saveQuestion(event));
    questionType.addEventListener("change", () => this.renderQuestionType());
    questionImage.addEventListener("change", () => {
      if (!questionImage.files?.[0]) return;
      this.pendingImage = questionImage.files[0];
      this.imageRemoved = false;
      this.showImagePreview(URL.createObjectURL(this.pendingImage), true);
    });
    removeImageBtn.addEventListener("click", () => {
      this.imageRemoved = true;
      this.pendingImage = null;
      questionImage.value = "";
      this.showImagePreview(null);
    });
    freeModeBtn.addEventListener("click", () => this.setPlayMode("free"));
    quizModeBtn.addEventListener("click", () => this.setPlayMode("questions"));
    
    // Resume button
    resumeGameBtn.addEventListener("click", () => this.resumeGame());
    
    // Restart button
    restartGameBtn.addEventListener("click", () => this.startCountdown());
    
    // Footer button binds
    pauseToggleBtn.addEventListener("click", () => this.togglePause());
    
    muteToggleBtn.addEventListener("click", () => {
      const isMuted = this.game.toggleMute();
      this.updateMuteUI(isMuted);
    });

    cameraToggleBtn.addEventListener("click", () => this.toggleWebcamPanel());
    
    debugToggleBtn.addEventListener("click", () => this.toggleDebugMode());

    // Window resize handler to adapt HUD scaling if necessary
    window.addEventListener("resize", () => this.handleResize());
    
    // Make sure we stop tracks on page close
    window.addEventListener("beforeunload", () => {
      this.tracker.stopCamera();
    });
  }

  renderBank() {
    const count = this.questions.length;
    bankCount.textContent = count ? `${count} pregunta${count === 1 ? "" : "s"} lista${count === 1 ? "" : "s"} para la misión` : "Agrega al menos una pregunta para jugar con desafíos";
    bankListCount.textContent = String(count);
    questionList.replaceChildren();
    this.questions.forEach((question, index) => {
      const item = document.createElement("div");
      item.className = "bank-item";
      const title = document.createElement("span");
      title.textContent = `${index + 1}. ${question.type === "open" ? "Abierta" : "Alternativas"}${question.image ? " · 🖼️" : ""} · ${question.prompt}`;
      const edit = document.createElement("button");
      edit.type = "button";
      edit.textContent = "Editar";
      edit.addEventListener("click", () => this.editQuestion(index));
      const remove = document.createElement("button");
      remove.type = "button";
      remove.textContent = "Eliminar";
      remove.addEventListener("click", () => {
        const next = this.questions.filter((_, i) => i !== index);
        try { saveQuestions(next); this.questions = next; }
        catch { this.showBankError("No se pudo actualizar el banco de preguntas."); return; }
        this.resetQuestionEditor();
        this.deck.reset();
        this.renderBank();
      });
      item.append(title, edit, remove);
      questionList.append(item);
    });
  }

  editQuestion(index) {
    const question = this.questions[index];
    this.editingIndex = index;
    this.pendingImage = null;
    this.imageRemoved = false;
    questionImage.value = "";
    this.showImagePreview(question.image || null);
    questionType.value = question.type === "open" ? "open" : "multiple";
    this.renderQuestionType();
    questionPrompt.value = question.prompt;
    if (question.type === "open") openAnswer.value = question.answer;
    else {
      optionInputs.forEach((input, i) => { input.value = question.options[i]; });
      correctOption.value = String(question.correct);
    }
    document.getElementById("saveQuestionBtn").textContent = "GUARDAR CAMBIOS";
    questionPrompt.focus();
  }

  showImagePreview(src, temporary = false) {
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
    this.previewUrl = temporary ? src : null;
    imagePreviewWrap.classList.toggle("field-hidden", !src);
    if (src) imagePreview.src = src;
    else imagePreview.removeAttribute("src");
  }

  showBankError(message) {
    bankError.textContent = message;
    bankError.classList.toggle("field-hidden", !message);
  }

  resetQuestionEditor() {
    this.editingIndex = -1;
    this.pendingImage = null;
    this.imageRemoved = false;
    this.showImagePreview(null);
    questionForm.reset();
    this.renderQuestionType();
    document.getElementById("saveQuestionBtn").textContent = "GUARDAR PREGUNTA";
  }

  async saveQuestion(event) {
    event.preventDefault();
    this.showBankError("");
    const question = questionType.value === "open"
      ? { type: "open", prompt: questionPrompt.value.trim(), answer: openAnswer.value.trim() }
      : { type: "multiple", prompt: questionPrompt.value.trim(), options: optionInputs.map((input) => input.value.trim()), correct: Number(correctOption.value) };
    if (!question.prompt || (question.type === "open" ? !question.answer : question.options.some((option) => !option))) return;
    try {
      const oldImage = this.editingIndex >= 0 ? this.questions[this.editingIndex].image : null;
      const image = this.pendingImage ? await compressQuestionImage(this.pendingImage) : (this.imageRemoved ? null : oldImage);
      if (image) question.image = image;
      const next = [...this.questions];
      if (this.editingIndex >= 0) next[this.editingIndex] = question;
      else next.push(question);
      saveQuestions(next);
      this.questions = next;
    } catch (error) {
      this.showBankError(error.name === "QuotaExceededError" ? "No queda espacio en este navegador. Prueba con menos imágenes." : error.message);
      return;
    }
    this.deck.reset();
    this.resetQuestionEditor();
    this.renderBank();
  }

  showQuestion() {
    this.activeQuiz = this.deck.next(this.questions);
    if (!this.activeQuiz) return;
    this.quizResolved = false;
    this.dwell.reset();
    activeQuestion.textContent = this.activeQuiz.prompt;
    activeQuestionImage.classList.toggle("field-hidden", !this.activeQuiz.image);
    if (this.activeQuiz.image) activeQuestionImage.src = this.activeQuiz.image;
    else activeQuestionImage.removeAttribute("src");
    answerFeedback.textContent = this.activeQuiz.type === "open" ? "Escribe tu respuesta para continuar." : "Apunta a una alternativa y mantén el dedo durante 5 segundos.";
    answerFeedback.className = "answer-feedback";
    answerOptions.replaceChildren();
    if (this.activeQuiz.type === "open") {
      const form = document.createElement("form");
      form.className = "open-answer-form";
      const input = document.createElement("input");
      input.required = true;
      input.maxLength = 240;
      input.placeholder = "Escribe tu respuesta";
      input.setAttribute("aria-label", "Tu respuesta");
      const submit = document.createElement("button");
      submit.type = "submit";
      submit.className = "answer-btn";
      submit.textContent = "COMPROBAR";
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        this.answerQuestion(input.value, submit);
      });
      form.append(input, submit);
      answerOptions.append(form);
    } else {
      this.activeQuiz.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "answer-btn";
        button.classList.toggle("long-answer", option.length > 35);
        button.textContent = `${"ABCD"[index]}. ${option}`;
        button.dataset.answerIndex = index;
        button.addEventListener("click", () => this.answerQuestion(index, button));
        answerOptions.append(button);
      });
    }
    this.transitionToState(STATES.QUESTION);
  }

  updateHandDwell(coords, now) {
    const quiz = this.currentState === STATES.QUESTION && this.activeQuiz?.type === "multiple" && !this.quizResolved;
    const overlay = this.currentState === STATES.PAUSED ? pauseOverlay : gameOverOverlay;
    const menu = this.currentState === STATES.PAUSED || this.currentState === STATES.GAME_OVER;
    this.handCursor.hidden = !(quiz || menu) || !coords || this.usePointer;
    if (this.handCursor.hidden) {
      this.dwell.target?.classList.remove("aimed");
      this.dwell.reset();
      return;
    }
    const area = quiz ? questionOverlay : overlay;
    const rect = area.getBoundingClientRect();
    const aimY = Math.max(0, Math.min(1, (coords.y - .12) / .72));
    const x = rect.left + coords.x * rect.width;
    const y = rect.top + aimY * rect.height;
    this.handCursor.style.left = `${x}px`;
    this.handCursor.style.top = `${y}px`;
    const hit = document.elementFromPoint(x, y)?.closest(quiz ? "[data-answer-index]" : "[data-orbit-dwell]");
    const target = hit && !hit.disabled && area.contains(hit) ? hit : null;
    if (this.dwell.target !== target) {
      this.dwell.target?.classList.remove("aimed");
      target?.classList.add("aimed");
    }
    const { progress, select } = this.dwell.update(target, now);
    this.handCursor.style.setProperty("--progress", `${progress * 360}deg`);
    if (select) target.click();
  }

  answerQuestion(index, button) {
    if (this.currentState !== STATES.QUESTION || this.quizResolved) return;
    const correct = this.activeQuiz.type === "open"
      ? matchesOpenAnswer(index, this.activeQuiz.answer)
      : index === this.activeQuiz.correct;
    if (!correct) {
      this.game.playSound("wrong");
      button.classList.add("wrong");
      if (this.activeQuiz.type !== "open") button.disabled = true;
      answerFeedback.textContent = "Aún no. Prueba otra respuesta.";
      answerFeedback.className = "answer-feedback wrong";
      return;
    }
    this.quizResolved = true;
    this.game.level++;
    this.updateHUD();
    button.classList.add("correct");
    answerFeedback.textContent = "¡Correcto! Nueva zona desbloqueada. Prepárate para el siguiente nivel.";
    answerFeedback.className = "answer-feedback correct";
    this.game.playSound("levelUp");
    setTimeout(() => {
      if (this.currentState !== STATES.QUESTION) return;
      this.game.lastTime = performance.now();
      this.game.safeUntil = this.game.gameTime + 1400;
      this.game.obstacleSpawnTimer = 0;
      this.handLostTime = null;
      // Give the ship a clear lane after the paused challenge.
      this.game.obstacles = this.game.obstacles.filter((obs) =>
        Math.hypot(obs.x - this.game.player.x, obs.y - this.game.player.y) > obs.radius + 70);
      this.transitionToState(STATES.PLAYING);
    }, 900);
  }

  setPlayMode(mode) {
    this.playMode = mode;
    localStorage.setItem("mandatin_play_mode", mode);
    this.renderMode();
    this.renderBank();
    this.updateHUD();
  }

  renderMode() {
    const free = this.playMode === "free";
    freeModeBtn.classList.toggle("selected", free);
    quizModeBtn.classList.toggle("selected", !free);
    freeModeBtn.setAttribute("aria-pressed", String(free));
    quizModeBtn.setAttribute("aria-pressed", String(!free));
    bankCount.classList.toggle("field-hidden", free);
  }

  renderQuestionType() {
    const open = questionType.value === "open";
    multipleFields.classList.toggle("field-hidden", open);
    openFields.classList.toggle("field-hidden", !open);
    optionInputs.forEach((input) => { input.required = !open; });
    openAnswer.required = open;
  }

  /**
   * State Machine transition handler
   * Handles showing/hiding appropriate modal screens and toggling DOM element states
   */
  transitionToState(newState) {
    this.currentState = newState;
    this.dwell.target?.classList.remove("aimed");
    this.dwell.reset();
    this.handCursor.hidden=true;
    document.getElementById("appContainer").dataset.state = newState;
    this.game.lastDrawAt = 0;
    
    // Hide all overlays first
    const overlays = [loadingOverlay, startOverlay, cameraSetupOverlay, bankOverlay, questionOverlay, countdownOverlay, pauseOverlay, trackingLostOverlay, gameOverOverlay];
    overlays.forEach(overlay => {
      overlay.classList.add("hidden");
      overlay.classList.remove("active");
    });

    // Reset specific elements
    pauseToggleBtn.disabled = true;

    switch (newState) {
      case STATES.LOADING:
        loadingOverlay.classList.remove("hidden");
        loadingOverlay.classList.add("active");
        break;

      case STATES.START_SCREEN:
        startOverlay.classList.remove("hidden");
        startOverlay.classList.add("active");
        break;

      case STATES.CAMERA_SETUP:
        cameraSetupOverlay.classList.remove("hidden");
        cameraSetupOverlay.classList.add("active");
        break;

      case STATES.BANK:
        bankOverlay.classList.remove("hidden");
        bankOverlay.classList.add("active");
        break;

      case STATES.QUESTION:
        questionOverlay.classList.remove("hidden");
        questionOverlay.classList.add("active");
        break;

      case STATES.COUNTDOWN:
        countdownOverlay.classList.remove("hidden");
        countdownOverlay.classList.add("active");
        this.countdownValue = 3;
        countdownText.classList.remove("launch");
        countdownText.textContent = this.countdownValue;
        this.countdownTimer = 0;
        break;

      case STATES.PLAYING:
        pauseToggleBtn.disabled = false;
        // Keep overlays hidden
        break;

      case STATES.PAUSED:
        pauseToggleBtn.disabled = false;
        pauseOverlay.classList.remove("hidden");
        pauseOverlay.classList.add("active");
        break;

      case STATES.GAME_OVER:
        gameOverOverlay.classList.remove("hidden");
        gameOverOverlay.classList.add("active");
        
        // Populate stats card
        finalScoreValText.textContent = this.game.score.toString().padStart(2, "0");
        finalLevelValText.textContent = this.game.level.toString().padStart(2, "0");
        
        // Show/hide High Score Chime badge
        if (this.game.score > 0 && this.game.score >= this.game.highScore) {
          newHighScoreBadge.classList.remove("hidden");
        } else {
          newHighScoreBadge.classList.add("hidden");
        }
        break;
    }
  }

  /**
   * Attempts to request camera permissions and start the game countdown
   */
  async openCameraSetup() {
    this.usePointer = false;
    document.getElementById('appContainer').dataset.control = 'camera';
    if (this.playMode === "questions" && !this.questions.length) {
      this.transitionToState(STATES.BANK);
      questionPrompt.focus();
      return;
    }
    this.transitionToState(STATES.CAMERA_SETUP);
    cameraSetupStatus.textContent = "Elige tu cámara y pulsa Probar cámara.";
    await this.refreshCameraList();
  }

  async refreshCameraList() {
    if (!navigator.mediaDevices?.enumerateDevices) return;
    try {
      const currentValue = cameraSelect.value;
      const cameras = (await navigator.mediaDevices.enumerateDevices()).filter((device) => device.kind === "videoinput");
      cameraSelect.replaceChildren(new Option("Cámara predeterminada", ""));
      cameras.forEach((camera, index) => cameraSelect.add(new Option(camera.label || `Cámara ${index + 1}`, camera.deviceId)));
      if (currentValue && cameras.some((camera) => camera.deviceId === currentValue)) {
        cameraSelect.value = currentValue;
      } else {
        const integrated = cameras.find((camera) => /facetime|integrada|built.in|macbook/i.test(camera.label) && !/obs/i.test(camera.label));
        if (integrated) cameraSelect.value = integrated.deviceId;
      }
    } catch (error) {
      console.warn("No se pudo enumerar las cámaras:", error);
    }
  }

  async testSelectedCamera() {
    if (this.cameraBusy) return false;
    this.cameraBusy = true;
    testCameraBtn.disabled = true;
    confirmCameraBtn.disabled = true;
    cameraSetupStatus.textContent = "Abriendo la cámara…";
    try {
      let selectedId = cameraSelect.value;
      const quality = qualitySelect.value;
      await this.tracker.startCamera(selectedId, quality);
      await this.refreshCameraList();
      // After Safari reveals device names, prefer the real Mac camera over OBS.
      if (!selectedId && cameraSelect.value) {
        selectedId = cameraSelect.value;
        await this.tracker.startCamera(selectedId, quality);
      }
      setupVideo.srcObject = this.tracker.stream;
      await setupVideo.play().catch(() => {});
      cameraPreviewPlaceholder.classList.add("hidden");
      cameraSetupStatus.textContent = "Cámara lista. Si ves OBS o una imagen negra, elige otra cámara y pulsa Probar cámara.";
      camIndicator.classList.remove("offline");
      camIndicator.classList.add("online");
      return true;
    } catch (error) {
      cameraSetupStatus.textContent = error.name === "NotAllowedError"
        ? "Permite el acceso a la cámara en Safari para este sitio."
        : "No pude abrir esa cámara. Prueba otra opción.";
      cameraPreviewPlaceholder.classList.remove("hidden");
      console.error("Camera preview failed:", error);
      return false;
    } finally {
      this.cameraBusy = false;
      testCameraBtn.disabled = false;
      confirmCameraBtn.disabled = false;
    }
  }

  async handleRequestCameraAndStart() {
    if (this.cameraBusy) return;
    if ((!this.tracker.stream || this.tracker.cameraDeviceId !== cameraSelect.value || this.tracker.cameraQuality !== qualitySelect.value)
      && !(await this.testSelectedCamera())) return;
    try {
      confirmCameraBtn.disabled = true;
      loadingStatusText.textContent = "Preparando seguimiento de la mano...";
      this.transitionToState(STATES.LOADING);
      if (!this.tracker.isInitialized) {
        await this.tracker.initialize((status) => { loadingStatusText.textContent = status; });
      }
      
      // Update webcam panel header indicators
      camIndicator.classList.remove("offline");
      camIndicator.classList.add("online");
      
      // Resume audio context
      this.game.initAudio();

      this.game.setLightMode(qualitySelect.value === "light");
      setupVideo.pause();
      setupVideo.srcObject = null;

      // Transition to game countdown
      this.startCountdown();
    } catch (error) {
      console.error("Camera permission denied or camera missing:", error);
      cameraSetupStatus.textContent = "No pude preparar el seguimiento. Comprueba la conexión e inténtalo de nuevo.";
      this.transitionToState(STATES.CAMERA_SETUP);
    } finally {
      confirmCameraBtn.disabled = false;
    }
  }

  /**
   * Resets scores, spawns entities, and begins countdown
   */
  startCountdown() {
    this.game.shieldsEnabled = document.getElementById('enableShields').checked;
    this.game.questionMode = this.playMode === "questions";
    this.game.reset();
    this.deck.reset();
    this.activeQuiz = null;
    this.updateHUD();
    this.handLostTime = null;
    this.isTrackingLostOverlayActive = false;
    trackingLostOverlay.classList.add("hidden");

    this.transitionToState(STATES.COUNTDOWN);
    this.game.playSound("countdown");
  }

  /**
   * Resumes gameplay from manual pause or tracking recovery
   */
  resumeGame() {
    this.game.initAudio();
    if (this.currentState === STATES.PAUSED) {
      this.transitionToState(STATES.PLAYING);
      
      // Set time baseline to prevent jump when resuming
      this.game.lastTime = performance.now();
    }
  }

  /**
   * Toggles pause/resume state
   */
  togglePause() {
    if (this.currentState === STATES.PLAYING) {
      this.transitionToState(STATES.PAUSED);
      this.updatePauseButtonUI(true);
    } else if (this.currentState === STATES.PAUSED) {
      this.resumeGame();
      this.updatePauseButtonUI(false);
    }
  }

  /**
   * Updates Pause toggle button SVG icons
   */
  updatePauseButtonUI(isPaused) {
    const pauseIcon = pauseToggleBtn.querySelector(".pause-icon");
    const playIcon = pauseToggleBtn.querySelector(".play-icon");
    const label = pauseToggleBtn.querySelector("span");

    if (isPaused) {
      pauseIcon.classList.add("hidden");
      playIcon.classList.remove("hidden");
      label.textContent = "CONTINUAR";
    } else {
      pauseIcon.classList.remove("hidden");
      playIcon.classList.add("hidden");
      label.textContent = "PAUSA";
    }
  }

  /**
   * Updates Mute/Unmute buttons UI
   */
  updateMuteUI(isMuted) {
    const volumeUp = muteToggleBtn.querySelector(".volume-up-icon");
    const volumeOff = muteToggleBtn.querySelector(".volume-off-icon");
    const label = document.getElementById("muteBtnText");

    if (isMuted) {
      volumeUp.classList.add("hidden");
      volumeOff.classList.remove("hidden");
      label.textContent = "SONIDO";
    } else {
      volumeUp.classList.remove("hidden");
      volumeOff.classList.add("hidden");
      label.textContent = "SILENCIO";
    }
  }

  /**
   * Hides or shows the corner webcam Picture-In-Picture panel
   */
  toggleWebcamPanel() {
    const isHidden = webcamPanel.classList.toggle("hidden");
    const label = document.getElementById("cameraBtnText");
    label.textContent = isHidden ? "MOSTRAR CÁMARA" : "OCULTAR CÁMARA";
  }

  /**
   * Toggles developer debugging overlay (FPS panel)
   */
  toggleDebugMode() {
    this.game.debugMode = !this.game.debugMode;
    if (this.game.debugMode) {
      fpsCounterContainer.classList.remove("hidden");
      debugToggleBtn.classList.add("neon-btn"); // add border highlight
      debugToggleBtn.style.color = "var(--neon-blue)";
    } else {
      fpsCounterContainer.classList.add("hidden");
      debugToggleBtn.classList.remove("neon-btn");
      debugToggleBtn.style.color = "";
    }
  }

  /**
   * Adapts layout on window resizing
   */
  handleResize() {
    // Canvas sizing adapts fluidly via CSS; no complex js scaling is required
  }

  /**
   * Refreshes numerical text elements in HUD
   */
  updateHUD() {
    scoreValText.textContent = this.game.score.toString().padStart(2, "0");
    levelValText.textContent = this.game.level.toString().padStart(2, "0");
    highScoreValText.textContent = this.game.highScore.toString().padStart(2, "0");
    questionProgressGroup.style.setProperty('--charge', ((this.currentState === STATES.QUESTION ? 4 : this.game.score%4)*25)+'%');
    const charge = this.currentState === STATES.QUESTION ? 4 : this.game.score % 4;
    questionProgress.textContent = this.playMode === "free" ? "—" : `${charge}/4`;
    
    if (this.game.debugMode) {
      fpsValText.textContent = this.game.fps.toString().padStart(2, "0");
    }
  }

  /**
   * Updates the HUD tracking indicator and coordinates status dots
   * @param {string} status - "green", "yellow", "red"
   */
  updateTrackingStatusIndicator(status) {
    if (status === this.lastTrackingStatus) return;
    this.lastTrackingStatus = status;

    // Reset dot classes
    trackingStatusDot.className = "status-dot " + status;

    // Update status labels
    switch (status) {
      case "green":
        trackingStatusText.textContent = "DETECTADO";
        trackingStatusText.style.color = "var(--neon-green)";
        break;
      case "yellow":
        trackingStatusText.textContent = "ESTABILIZANDO...";
        trackingStatusText.style.color = "var(--neon-yellow)";
        break;
      case "red":
        trackingStatusText.textContent = "PERDIDO";
        trackingStatusText.style.color = "var(--neon-red)";
        break;
    }
  }

  /**
   * Core frame rendering & update step orchestrated by requestAnimationFrame
   * @param {number} timestamp - Hi-res timestamp
   */
  tick(timestamp) {
    // 1. Process webcam hand tracking
    const fingerCoords = this.usePointer ? this.pointerCoords : this.tracker.detectFrame();
    const now = performance.now();
    this.updateHandDwell(fingerCoords, now);

    if (fingerCoords) {
      // Hand is detected, update target coordinates
      this.game.setTargetPosition(fingerCoords);
      
      // Update tracking status HUD
      this.updateTrackingStatusIndicator("green");
      
      // Cancel tracking lost sequences
      this.handLostTime = null;
      
      if (this.isTrackingLostOverlayActive) {
        this.isTrackingLostOverlayActive = false;
        trackingLostOverlay.classList.add("hidden");
        
        // Play resume audio cues
        this.game.playSound("countdownStart");
        
        if (this.currentState === STATES.PLAYING) {
          this.game.lastTime = now; // reset baseline to avoid leaps
        }
      }
    } else {
      // Hand tracking lost
      if (this.tracker.isTracking) {
        // Tracker is processing, but index finger or hand is unstable
        this.updateTrackingStatusIndicator("yellow");
      } else {
        // Hand is completely offline
        this.updateTrackingStatusIndicator("red");
      }

      // Check if we are playing and need to trigger the 1-second timeout warning
      if (this.currentState === STATES.PLAYING && !this.isTrackingLostOverlayActive) {
        if (!this.handLostTime) {
          this.handLostTime = now;
        } else if (now - this.handLostTime > 1000) {
          // Lost for > 1 second: Trigger Pause overlay
          this.isTrackingLostOverlayActive = true;
          trackingLostOverlay.classList.remove("hidden");
        }
      }
    }

    // 2. State Machine updates
    switch (this.currentState) {
      case STATES.COUNTDOWN:
        // Update countdown clock
        if (!this.countdownTimer) this.countdownTimer = timestamp;
        
        const elapsed = timestamp - this.countdownTimer;
        
        // Progress countdown every 1000ms
        if (elapsed >= 1000) {
          this.countdownValue--;
          this.countdownTimer = timestamp;
          
          if (this.countdownValue > 0) {
            countdownText.textContent = this.countdownValue;
            this.game.playSound("countdown");
          } else if (this.countdownValue === 0) {
            countdownText.textContent = "¡YA!";
            countdownText.classList.add("launch");
            this.game.playSound("countdownStart");
          } else {
            // End of countdown, start the game
            this.transitionToState(STATES.PLAYING);
            this.game.lastTime = timestamp; // set start timeline
          }
        }
        
        // Keep rendering the canvas so player sees their position during countdown
        this.game.draw();
        break;

      case STATES.PLAYING:
        // If tracking is lost and overlay is visible, pause updates but keep rendering
        if (this.isTrackingLostOverlayActive) {
          this.game.draw();
          break;
        }

        // Run game logic update
        const event = this.game.update(timestamp);
        
        if (event === "gameover") {
          this.transitionToState(STATES.GAME_OVER);
          this.updatePauseButtonUI(true); // reset play/pause label
        }
        if (this.playMode === "questions" && event === "coin" && this.game.score % 4 === 0) {
          this.showQuestion();
        }
        
        // Render updated canvas
        this.game.draw();
        
        // Sync score HUD
        this.updateHUD();
        break;

      case STATES.PAUSED:
      case STATES.QUESTION:
      case STATES.BANK:
      case STATES.GAME_OVER:
      case STATES.START_SCREEN:
        // Keep rendering with the last known frames so the background/glow trails look clean
        this.game.draw();
        if (this.game.debugMode) {
          this.updateHUD();
        }
        break;
    }

    // Request next animation frame
    requestAnimationFrame((t) => this.tick(t));
  }
}

// Instantiate and start app on page load
window.addEventListener("DOMContentLoaded", () => {
  const app = new AppController();
  app.init();
  
  // Start the render loop
  requestAnimationFrame((t) => app.tick(t));
});
