// Phaser is distributed locally under the MIT license (vendor/PHASER-LICENSE.txt).
export class OrbitRenderer {
  constructor(model) {
    this.model = model;
    const host = document.createElement('div');
    host.id = 'orbitStage';
    model.canvas.after(host);
    this.host=host;
    const owner = this;
    this.engine = new Phaser.Game({
      type: Phaser.AUTO, parent: host, width: 800, height: 450,
      transparent: true,
      scale: { mode: Phaser.Scale.NONE },
      render: { antialias: true, roundPixels: false },
      fps: { target: 60, limit: 30 }, audio: { noAudio: true },
      scene: {
        preload() {
          this.load.image('pilot', './mandatin-nave.png');
          this.load.image('rock', './art/asteroid.png');
          this.load.image('energy', './art/energy.png');
        },
        create() { owner.create(this); },
        update(t) { owner.update(t); }
      }
    });
  }
  create(scene) {
    this.scene = scene;
    if(!scene.textures.exists('rock')) this.makeRock(scene);
    if(!scene.textures.exists('energy')) this.makeEnergy(scene);
    this.dust = Array.from({length:18},(_,i)=>scene.add.circle((i*173)%800,(i*89)%450, i%4?1:2,0x9deaff,.5));
    this.flame=scene.add.ellipse(400,258,15,36,0x23b7ee,.5);
    this.flameCore=scene.add.ellipse(400,255,7,23,0xd2ffff,.9).setDepth(3);
    this.ship=scene.add.image(400,225,'pilot').setDisplaySize(90,90);
    this.halo=scene.add.ellipse(400,249,65,17,0x38c7ef,.13).setDepth(2);
    const shieldArt=scene.add.graphics();
    shieldArt.fillStyle(0x137ac5,1);shieldArt.lineStyle(3,0xb6efff,1);
    shieldArt.beginPath();shieldArt.moveTo(32,5);shieldArt.lineTo(55,15);shieldArt.lineTo(51,40);shieldArt.lineTo(32,59);shieldArt.lineTo(13,40);shieldArt.lineTo(9,15);shieldArt.closePath();shieldArt.fillPath();shieldArt.strokePath();
    shieldArt.lineStyle(4,0xffffff,1);shieldArt.lineBetween(32,19,32,43);shieldArt.lineBetween(22,31,42,31);
    shieldArt.generateTexture('shield',64,64);shieldArt.destroy();
    this.shieldItem=scene.add.image(0,0,'shield').setDisplaySize(43,43).setDepth(5).setVisible(false);
    this.shieldBubble=scene.add.circle(0,0,49,0x2186c9,.16).setStrokeStyle(2,0x90e8ff,1).setDepth(5).setVisible(false);
    this.shieldLabel=scene.add.text(0,0,'',{fontFamily:'sans-serif',fontSize:'14px',fontStyle:'bold',color:'#c7f6ff',backgroundColor:'#082a48',padding:{x:5,y:3}}).setOrigin(.5).setDepth(6).setVisible(false);
    this.rocks=[]; this.cells=[];
    this.charge=Array.from({length:4},()=>scene.add.rectangle(0,0,10,4,0x17364a).setStrokeStyle(1,0x67cece,.6).setDepth(5));
    this.lastScore=this.model.score;
    this.flash=scene.add.circle(0,0,15,0x7cffb0,0).setStrokeStyle(2,0xafffd6,0).setDepth(6);
    this.ready=true;
    this.resizeObserver=new ResizeObserver(()=>this.resize());
    this.resizeObserver.observe(this.host);
    this.resize();
    this.model.canvas.style.visibility='hidden';
  }
  resize() {
    if(!this.ready)return;
    const rect=this.host.getBoundingClientRect();
    if(!rect.width||!rect.height)return;
    const width=Math.round(Math.min(this.model.lightMode?800:1600,Math.max(800,rect.width)));
    const height=Math.round(width*rect.height/rect.width);
    this.engine.scale.resize(width,height);
    this.scene.cameras.main.setZoom(width/800).setOrigin(0,0).setScroll(0,0);
    this.model.config.height=800*rect.height/rect.width;
    const h=this.model.config.height;
    for(const obj of [this.model.player,...this.model.coins,...(this.model.shieldPickup?[this.model.shieldPickup]:[])]) obj.y=Math.max(25,Math.min(h-25,obj.y));
  }
  makeRock(s) {
    const t=s.textures.createCanvas('rock',96,96), c=t.context;
    const g=c.createRadialGradient(25,20,2,48,48,50); g.addColorStop(0,'#dba18d'); g.addColorStop(.5,'#986875'); g.addColorStop(1,'#3a294c');
    c.fillStyle=g; c.strokeStyle='#e6ab9188'; c.lineWidth=3; c.beginPath();
    for(let i=0;i<12;i++){const a=i*Math.PI/6,r=38+(i%3)*3; const x=48+Math.cos(a)*r,y=48+Math.sin(a)*r; i?c.lineTo(x,y):c.moveTo(x,y);} c.closePath();c.fill();c.stroke();
    for(const [x,y,r] of [[30,31,10],[63,51,12],[35,68,6]]) {c.fillStyle='#412e4a88';c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();c.strokeStyle='#e5a89966';c.lineWidth=2;c.beginPath();c.arc(x,y+2,r,0,Math.PI);c.stroke();} t.refresh();
  }
  makeEnergy(s) {
    const t=s.textures.createCanvas('energy',64,64),c=t.context;
    c.strokeStyle='#71ffaf66';c.lineWidth=2;c.beginPath();c.arc(32,32,27,0,Math.PI*2);c.stroke();
    c.fillStyle='#31bd87';c.beginPath();c.moveTo(32,5);c.lineTo(49,32);c.lineTo(32,59);c.lineTo(15,32);c.closePath();c.fill();
    c.fillStyle='#bcffe2';c.beginPath();c.moveTo(32,5);c.lineTo(32,32);c.lineTo(15,32);c.closePath();c.fill();
    c.fillStyle='#6dffb1';c.beginPath();c.moveTo(32,32);c.lineTo(49,32);c.lineTo(32,59);c.closePath();c.fill();t.refresh();
  }
  sync(pool, objects, key) {
    objects.forEach((o,i)=>{if(!pool[i])pool[i]=this.scene.add.image(0,0,key); const sprite=pool[i];sprite.setVisible(true).setPosition(o.x,o.y).setDisplaySize(o.radius*2.4,o.radius*2.4).setRotation(o.rotation||0).setTint(o.tint||0xffffff);});
    for(let i=objects.length;i<pool.length;i++)pool[i].setVisible(false);
  }
  update(t) {
    if(!this.ready)return;
    const m=this.model;
    const playing=document.getElementById('appContainer').dataset.state==='PLAYING';
    this.ship.setPosition(m.player.x,m.player.y).setRotation(Math.max(-.12,Math.min(.12,(m.player.targetX-m.player.x)*.002)));
    this.flame.setPosition(m.player.x,m.player.y+29).setScale(1,.7+Math.sin(t*.02)*.2);
    this.flameCore.setPosition(m.player.x,m.player.y+29).setScale(1,.8+Math.sin(t*.02)*.2).setVisible(playing);
    this.halo.setPosition(m.player.x,m.player.y+24).setAlpha(m.gameTime<m.safeUntil?.5:.13);
    this.charge.forEach((bar,i)=>bar.setPosition(m.player.x-18+i*12,m.player.y+44).setFillStyle(i<(m.score%4 || (document.getElementById('appContainer').dataset.state==='QUESTION'?4:0))?0x70ffc0:0x17364a));
    this.flame.setVisible(playing);
    this.dust.forEach((p,i)=>{if(playing&&!m.lightMode)p.y=(p.y+.12+(i%3)*.1)%m.config.height;});
    this.sync(this.rocks,m.obstacles,'rock');this.sync(this.cells,m.coins,'energy');
    this.cells.forEach((cell,i)=>{ if(cell.visible)cell.setScale((m.coins[i].radius*2.8/128)*(1+Math.sin(t*.003)*.06)); });
    const remaining=Math.max(0,m.shieldUntil-m.gameTime);
    this.shieldBubble.setVisible(remaining>0).setPosition(m.player.x,m.player.y).setAlpha(remaining<1500?.55+.35*Math.sin(t*.012):1);
    this.shieldLabel.setVisible(remaining>0).setPosition(m.player.x,m.player.y-61);
    const seconds=Math.ceil(remaining/1000);
    if(seconds!==this.lastShieldSeconds) {this.shieldLabel.setText('ESCUDO '+seconds+' s');this.lastShieldSeconds=seconds;}
    this.shieldItem.setVisible(!!m.shieldPickup);
    if(m.shieldPickup)this.shieldItem.setPosition(m.shieldPickup.x,m.shieldPickup.y).setRotation(Math.sin(t*.003)*.12);
    this.ship.setDepth(4);this.flame.setDepth(3);
    if(m.score>this.lastScore){this.flash.setPosition(m.player.x,m.player.y).setScale(1).setAlpha(1).setStrokeStyle(2,0xafffd6,1);this.scene.tweens.add({targets:this.flash,scale:4,alpha:0,duration:380});}
    this.lastScore=m.score;
  }
  setLightMode(enabled) { this.dust?.forEach(p => p.setVisible(!enabled)); this.resize(); }
}
