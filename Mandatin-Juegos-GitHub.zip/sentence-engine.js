export const DEFAULT_SENTENCES = [
  "Mandatín viaja por el espacio.",
  "La nave recoge energía verde.",
  "Los estudiantes aprenden jugando."
];

const STORAGE_KEY = "mandatin_sentences_v1";

export function cleanSentence(value) {
  return String(value || "").trim().replace(/\s+/g, " ");
}

export function cleanContext(value) {
  return String(value || "").trim().replace(/\s+/g, " ").slice(0, 300);
}

export function sentenceWords(value) {
  return cleanSentence(value).split(" ").filter(Boolean);
}

export function isValidSentence(value) {
  const words = sentenceWords(value);
  return words.length >= 3 && words.length <= 12 && cleanSentence(value).length <= 180;
}

export function normalizeSentenceEntry(value) {
  const sentence = cleanSentence(typeof value === "string" ? value : value?.sentence);
  if (!isValidSentence(sentence)) return null;
  return { sentence, context: cleanContext(typeof value === "string" ? "" : value?.context) };
}

export function loadSentences(storage = globalThis.localStorage) {
  try {
    const stored = JSON.parse(storage.getItem(STORAGE_KEY));
    if (Array.isArray(stored)) return stored.map(normalizeSentenceEntry).filter(Boolean);
  } catch { /* Use the initial examples when storage is unavailable or corrupt. */ }
  return DEFAULT_SENTENCES.map((sentence, index) => ({
    sentence,
    context: index === 0 ? "¿Por dónde viaja Mandatín?" : ""
  }));
}

export function saveSentences(sentences, storage = globalThis.localStorage) {
  storage.setItem(STORAGE_KEY, JSON.stringify(sentences.map(normalizeSentenceEntry).filter(Boolean)));
}

export function shuffledIndexes(count, random = Math.random) {
  const indexes = Array.from({ length: count }, (_, index) => index);
  for (let i = indexes.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    [indexes[i], indexes[j]] = [indexes[j], indexes[i]];
  }
  if (count > 1 && indexes.every((value, index) => value === index)) {
    [indexes[0], indexes[1]] = [indexes[1], indexes[0]];
  }
  return indexes;
}

export function isCorrectOrder(placements) {
  return placements.every((value, index) => value === index);
}

// A fist folds most fingertips closer to the wrist than their middle joints.
// The result is intentionally ternary so ambiguous poses don't move a tile.
export function classifyHand(landmarks) {
  if (!Array.isArray(landmarks) || landmarks.length < 21) return "unknown";
  const wrist = landmarks[0];
  let extended = 0;
  for (const [tipIndex, middleIndex] of [[8, 6], [12, 10], [16, 14], [20, 18]]) {
    const tip = landmarks[tipIndex];
    const middle = landmarks[middleIndex];
    const tipDistance = Math.hypot(tip.x - wrist.x, tip.y - wrist.y);
    const middleDistance = Math.hypot(middle.x - wrist.x, middle.y - wrist.y);
    if (tipDistance > middleDistance * 1.12) extended += 1;
  }
  // One raised index finger is pointing, not grabbing.
  if (extended === 0) return "fist";
  if (extended >= 3) return "open";
  return "unknown";
}
