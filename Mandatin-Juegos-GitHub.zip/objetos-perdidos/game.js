import { HandTracker } from '../handTracking.js';
import { FingerFilter } from '../finger-filter.js';
import { DwellSelector } from '../dwell-selector.js';
import { GestureReader } from './gestures.js';
import { savedScene } from './scene-storage.js';

const el = (id) => document.getElementById(id);
const stage = el('stage');
const world = el('world');
const scene = el('scene');
const marks = el('marks');
const cursor = el('cursor');
const video = el('video');
const overlay = el('overlay');
const nameInput = el('object-name');
const deviceSelect = el('device');
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const demo = {
  title: 'El invernadero secreto',
  source: new URL('./invernadero-ilustrado.webp', import.meta.url).href,
  targets: [
    ['Brújula', 741, 603, 169, 98],
    ['Llave dorada', 178, 307, 112, 65],
    ['Regadera', 1503, 205, 235, 148],
    ['Lupa', 1093, 335, 153, 118],
    ['Estrella', 1538, 597, 85, 67]
  ].map(([name, x, y, w, h]) => ({ name, x: x / 1774, y: y / 887, w: w / 1774, h: h / 887 }))
};
const reader = new GestureReader();
const finger = new FingerFilter();
const selectionSeconds = 3;
const dwell = new DwellSelector(selectionSeconds * 1000);

let board = demo;
let customBoard = null;
let imageUrl = null;
let imageSequence = 0;
let noticeTimer;
let editing = false;
let found = 0;
let drag = null;
let draft = null;
let tracker = null;
let cameraReady = false;
let cameraLoop = 0;
let lastSample = -1;
let gesture = null;
let anchor = null;
let cameraId = '';
let view = { width: 0, height: 0, zoom: 1, x: 0, y: 0 };

function showNotice(message) {
  const notice = el('notice');
  notice.textContent = message;
  notice.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => { notice.hidden = true; }, 3400);
}

function setView(zoom, x, y) {
  if (!view.width) return;
  const limit = (extent, size, offset) => {
    const room = extent - size;
    const gutter = Math.min(48, extent * 0.1);
    return clamp(offset, Math.min(0, room) - gutter, Math.max(0, room) + gutter);
  };
  view = {
    ...view, zoom,
    x: limit(stage.clientWidth, view.width * zoom, x),
    y: limit(stage.clientHeight, view.height * zoom, y)
  };
  world.style.transform = `translate3d(${view.x}px,${view.y}px,0) scale(${zoom})`;
  el('zoom-value').textContent = `${Math.round(zoom * 100)}%`;
  el('out').disabled = zoom <= 0.65;
  el('in').disabled = zoom >= 6;
}

function fit() {
  if (!scene.naturalWidth || !stage.clientWidth) return;
  const scale = Math.min(stage.clientWidth / scene.naturalWidth, stage.clientHeight / scene.naturalHeight);
  view.width = scene.naturalWidth * scale;
  view.height = scene.naturalHeight * scale;
  world.style.width = `${view.width}px`;
  world.style.height = `${view.height}px`;
  setView(1, (stage.clientWidth - view.width) / 2, (stage.clientHeight - view.height) / 2);
  resetGesture();
}

function zoomAt(factor, from = { x: stage.clientWidth / 2, y: stage.clientHeight / 2 }, to = from) {
  const zoom = clamp(view.zoom * factor, 0.65, 6);
  const ratio = zoom / view.zoom;
  setView(zoom, to.x - (from.x - view.x) * ratio, to.y - (from.y - view.y) * ratio);
}

function screenPoint(event) {
  const rect = stage.getBoundingClientRect();
  return { x: event.clientX - rect.left, y: event.clientY - rect.top };
}

function scenePoint(point) {
  return { x: (point.x - view.x) / (view.width * view.zoom), y: (point.y - view.y) / (view.height * view.zoom) };
}

function inside({ x, y }) {
  return x >= 0 && x <= 1 && y >= 0 && y <= 1;
}

function makeMark(target, style = '') {
  const mark = document.createElement('div');
  mark.className = `mark ${style}`;
  for (const [prop, key] of Object.entries({ left: 'x', top: 'y', width: 'w', height: 'h' })) {
    mark.style[prop] = `${target[key] * 100}%`;
  }
  return mark;
}

function renderMarks() {
  const visible = editing ? board.targets : board.targets.slice(0, found);
  const nodes = visible.map((target) => makeMark(target, editing ? '' : 'found'));
  if (draft) nodes.push(makeMark(draft, 'draft'));
  marks.replaceChildren(...nodes);
}

function renderLists() {
  const list = el(editing ? 'edit-targets' : 'targets');
  list.replaceChildren(...board.targets.map((target, index) => {
    const row = document.createElement('li');
    if (!editing) row.className = index < found ? 'done' : index === found ? 'current' : '';
    const number = document.createElement('span');
    number.className = 'target-index';
    number.textContent = !editing && index < found ? '✓' : String(index + 1).padStart(2, '0');
    const label = document.createElement('span');
    label.className = 'target-name';
    label.textContent = target.name;
    row.append(number, label);
    if (editing) {
      const remove = document.createElement('button');
      remove.textContent = '×';
      remove.setAttribute('aria-label', `Quitar ${target.name}`);
      remove.addEventListener('click', () => {
        board.targets.splice(index, 1);
        renderLists();
        renderMarks();
      });
      row.append(remove);
    } else if (index === found) {
      row.setAttribute('aria-current', 'step');
    }
    return row;
  }));
  el('score').textContent = `${found} / ${board.targets.length}`;
  el('meter-fill').style.width = `${100 * found / (board.targets.length || 1)}%`;
  el('play').disabled = board.targets.length === 0;
  const objective = board.targets[found];
  el('objective').hidden = editing || !objective;
  el('current-target').textContent = objective?.name || '';
  el('current-target').title = objective?.name || '';
}

function setMode(edit) {
  editing = edit;
  found = 0;
  draft = null;
  drag = null;
  stage.classList.remove('dragging');
  stage.classList.toggle('editing', edit);
  el('editor').hidden = !edit;
  el('dock').hidden = edit;
  el('win').hidden = true;
  el('mode').textContent = edit ? 'PREPARACIÓN' : 'EXPLORACIÓN';
  el('scene-tip').textContent = edit
    ? 'Escribe un nombre y marca el objeto sobre la imagen.'
    : 'Pinza para mover, dos pinzas para acercar o alejar.';
  el('editor-status').textContent = '';
  nameInput.value = '';
  if (edit) stopCamera();
  resetGesture();
  renderLists();
  renderMarks();
  fit();
  if (edit) nameInput.focus({ preventScroll: true });
}

function showGame() {
  el('menu-view').hidden = true;
  el('game-view').hidden = false;
  window.scrollTo(0, 0);
  fit();
}

function showMenu() {
  stopCamera();
  el('game-view').hidden = true;
  el('menu-view').hidden = false;
  window.scrollTo(0, 0);
  el('menu-play').focus({ preventScroll: true });
}

async function loadBoard(next, edit = false) {
  const ticket = ++imageSequence;
  const source = next.file ? URL.createObjectURL(next.file) : next.source;
  const probe = new Image();
  probe.src = source;
  try {
    await probe.decode();
    if (!probe.naturalWidth || !probe.naturalHeight || probe.naturalWidth * probe.naturalHeight > 40_000_000) {
      throw new Error('Usa una imagen de hasta 40 megapíxeles.');
    }
    if (ticket !== imageSequence) return;
    if (imageUrl) URL.revokeObjectURL(imageUrl);
    imageUrl = next.file ? source : null;
    board = { ...next, targets: next.targets.map((target) => ({ ...target })) };
    scene.src = source;
    el('scene-name').textContent = board.title;
    if (edit) showGame();
    setMode(edit);
  } catch (error) {
    if (ticket === imageSequence) showNotice(error.message === 'Usa una imagen de hasta 40 megapíxeles.'
      ? error.message : 'No pude abrir esa imagen. Prueba con PNG, JPEG o WebP.');
  } finally {
    if (next.file && source !== imageUrl) URL.revokeObjectURL(source);
  }
}

function choose(point) {
  const target = board.targets[found];
  if (editing || !target || !inside(point)) return;
  const { x, y, w, h } = target;
  if (point.x < x || point.x > x + w || point.y < y || point.y > y + h) {
    showNotice(`Sigue buscando: ${target.name}`);
    return;
  }
  found += 1;
  showNotice(`¡Encontraste: ${target.name}!`);
  renderLists();
  renderMarks();
  if (found === board.targets.length) {
    el('win').hidden = false;
    resetGesture();
  }
}

function region(from, to, moved) {
  const a = { x: clamp(from.x, 0, 1), y: clamp(from.y, 0, 1) };
  const b = { x: clamp(to.x, 0, 1), y: clamp(to.y, 0, 1) };
  const w = clamp(moved ? Math.abs(a.x - b.x) : 0.055, 0.006, 1);
  const h = clamp(moved ? Math.abs(a.y - b.y) : 0.055, 0.006, 1);
  return {
    x: clamp(moved ? Math.min(a.x, b.x) : a.x - w / 2, 0, 1 - w),
    y: clamp(moved ? Math.min(a.y, b.y) : a.y - h / 2, 0, 1 - h),
    w, h
  };
}

function beginDrag(event) {
  if (drag || !view.width || !el('win').hidden || event.button !== 0) return;
  const start = screenPoint(event);
  if (editing && !inside(scenePoint(start))) return;
  if (editing && !nameInput.value.trim()) {
    el('editor-status').textContent = 'Escribe primero el nombre del objeto.';
    nameInput.focus({ preventScroll: true });
    return;
  }
  resetGesture();
  drag = { id: event.pointerId, start, worldStart: scenePoint(start), x: view.x, y: view.y, moved: false };
  stage.setPointerCapture(event.pointerId);
}

function moveDrag(event) {
  if (drag?.id !== event.pointerId) return;
  const point = screenPoint(event);
  const dx = point.x - drag.start.x;
  const dy = point.y - drag.start.y;
  drag.moved ||= Math.hypot(dx, dy) > 5;
  if (!drag.moved) return;
  if (editing) {
    draft = region(drag.worldStart, scenePoint(point), true);
    renderMarks();
  } else {
    stage.classList.add('dragging');
    setView(view.zoom, drag.x + dx, drag.y + dy);
  }
}

function endDrag(event, cancel = false) {
  if (drag?.id !== event.pointerId) return;
  const { worldStart, moved } = drag;
  drag = null;
  draft = null;
  stage.classList.remove('dragging');
  if (cancel) { renderMarks(); return; }
  const point = scenePoint(screenPoint(event));
  if (!editing) {
    if (!moved) choose(point);
    return;
  }
  const name = nameInput.value.trim();
  if (!name) { renderMarks(); return; }
  board.targets.push({ name, ...region(worldStart, point, moved) });
  el('editor-status').textContent = `Zona guardada: ${name}.`;
  nameInput.value = '';
  nameInput.focus({ preventScroll: true });
  renderLists();
  renderMarks();
}

function resetGesture() {
  gesture = null;
  anchor = null;
  reader.reset();
  finger.reset();
  dwell.reset();
  cursor.hidden = true;
}

const gestureLabels = {
  idle: 'Muestra tu mano', ready: 'Haz una pinza o apunta',
  point: `Apuntando · mantén ${selectionSeconds} s`, pan: 'Moviendo imagen', zoom: 'Ajustando zoom'
};

function applyGesture(next, now) {
  const label = gestureLabels[next.mode];
  if (el('gesture').textContent !== label) el('gesture').textContent = label;
  const previous = gesture;
  const changedHand = next.wrist && previous?.wrist &&
    Math.hypot(next.wrist.x - previous.wrist.x, next.wrist.y - previous.wrist.y) > 0.22;
  const same = previous?.mode === next.mode && !changedHand;
  if (next.mode !== 'point' || !same) {
    dwell.reset();
    finger.reset();
    anchor = null;
    cursor.hidden = true;
  }
  gesture = next;
  if (!next.point) return;
  const toPixels = ({ x, y }) => ({ x: x * stage.clientWidth, y: y * stage.clientHeight });
  if (same && next.mode === 'pan') {
    const from = toPixels(previous.point);
    const to = toPixels(next.point);
    setView(view.zoom, view.x + to.x - from.x, view.y + to.y - from.y);
  } else if (same && next.mode === 'zoom') {
    const ratio = clamp(next.spread / previous.spread, 0.84, 1.19);
    zoomAt(ratio, toPixels(previous.point), toPixels(next.point));
  } else if (next.mode === 'point') {
    // A small margin lets a fingertip reach the edges without leaving the camera frame.
    const p = finger.update({ x: (next.point.x - 0.07) / 0.86, y: (next.point.y - 0.07) / 0.86 }, now);
    const pixel = toPixels(p);
    const position = scenePoint(pixel);
    const radius = clamp(Math.min(stage.clientWidth, stage.clientHeight) * 0.043, 14, 24);
    const current = board.targets[found];
    const onTarget = current && position.x >= current.x && position.x <= current.x + current.w &&
      position.y >= current.y && position.y <= current.y + current.h;
    const key = inside(position) ? (onTarget ? 'target' : 'scene') : null;
    if (!anchor || Math.hypot(anchor.x - pixel.x, anchor.y - pixel.y) > radius) {
      anchor = pixel;
      dwell.reset();
    }
    const hold = dwell.update(key, now);
    cursor.style.transform = `translate3d(${pixel.x}px,${pixel.y}px,0)`;
    cursor.style.setProperty('--hold', `${hold.progress * 100}%`);
    cursor.hidden = false;
    if (hold.select) choose(position);
  }
}

function runCamera() {
  cameraLoop = requestAnimationFrame(runCamera);
  if (document.hidden || editing || !el('win').hidden) return;
  tracker.detectFrame();
  const now = performance.now();
  const sample = tracker.lastResultAt;
  if (now - sample > 350 || drag) {
    if (gesture) resetGesture();
    el('gesture').textContent = gestureLabels.idle;
    return;
  }
  if (sample === lastSample) return;
  if (sample - lastSample > 350) resetGesture();
  lastSample = sample;
  applyGesture(reader.read(tracker.latestHands, video.videoWidth / video.videoHeight || 4 / 3), sample);
}

function stopCamera(message = 'Cámara apagada. Puedes jugar con mouse o pantalla táctil.') {
  cancelAnimationFrame(cameraLoop);
  tracker?.stopCamera();
  tracker = null;
  cameraReady = false;
  lastSample = -1;
  el('camera').disabled = false;
  el('camera').textContent = '◉ Activar cámara';
  el('camera-status').textContent = message;
  el('camera-feed').hidden = true;
  el('camera-placeholder').hidden = false;
  el('device-label').hidden = true;
  el('camera-light').classList.add('off');
  resetGesture();
}

async function updateDevices(currentTracker) {
  const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
  if (tracker !== currentTracker) return;
  const cameras = devices.filter((device) => device.kind === 'videoinput' && device.deviceId);
  deviceSelect.replaceChildren(...cameras.map((device, index) =>
    new Option(device.label || `Cámara ${index + 1}`, device.deviceId)
  ));
  cameraId = currentTracker.stream?.getVideoTracks()[0]?.getSettings().deviceId || cameraId;
  deviceSelect.value = cameraId;
  el('device-label').hidden = cameras.length < 2;
}

async function startCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    stopCamera('La cámara necesita una página HTTPS o localhost.');
    return;
  }
  if (tracker) stopCamera();
  const current = new HandTracker(video, overlay, { numHands: 2 });
  tracker = current;
  el('camera').textContent = 'Conectando cámara…';
  el('camera').disabled = true;
  el('camera-status').textContent = 'Autoriza el acceso a la cámara en el navegador.';
  try {
    await current.startCamera(cameraId, 'light');
    if (tracker !== current) return;
    const aspect = video.videoWidth / video.videoHeight || 4 / 3;
    overlay.height = Math.max(1, Math.round(overlay.width / aspect));
    el('camera-placeholder').hidden = true;
    el('camera-feed').hidden = false;
    el('gesture').textContent = 'Preparando gestos…';
    el('camera').textContent = 'Apagar cámara';
    el('camera').disabled = false;
    await current.initialize((message) => {
      if (tracker === current) el('camera-status').textContent = message;
    });
    if (tracker !== current) return;
    cameraReady = true;
    el('camera-light').classList.remove('off');
    el('camera-status').textContent = 'Cámara lista. Mantén las manos dentro del recuadro.';
    updateDevices(current);
    runCamera();
  } catch (error) {
    if (tracker !== current) return;
    const denied = error.name === 'NotAllowedError';
    const unavailable = ['NotFoundError', 'NotReadableError', 'OverconstrainedError'].includes(error.name);
    if (unavailable) cameraId = '';
    stopCamera(denied ? 'Permite la cámara en el navegador e inténtalo de nuevo.'
      : unavailable ? 'No pude abrir la cámara. Revisa si otra app la está usando.'
        : 'No pude cargar el seguimiento. Revisa tu conexión o juega con mouse.');
  } finally {
    if (tracker !== current) {
      // A request may finish after leaving play mode.
      if (video.srcObject === current.stream) current.stopCamera();
      else {
        current.stream?.getTracks().forEach((track) => track.stop());
        current.worker?.terminate();
        current.handLandmarker?.close();
      }
    }
  }
}

stage.addEventListener('pointerdown', beginDrag);
stage.addEventListener('pointermove', moveDrag);
stage.addEventListener('pointerup', endDrag);
stage.addEventListener('pointercancel', (event) => endDrag(event, true));
stage.addEventListener('lostpointercapture', (event) => endDrag(event, true));
stage.addEventListener('wheel', (event) => {
  if (!el('win').hidden || drag) return;
  event.preventDefault();
  resetGesture();
  zoomAt(Math.exp(-clamp(event.deltaY, -120, 120) * 0.003), screenPoint(event));
}, { passive: false });
stage.addEventListener('keydown', (event) => {
  if (event.target !== stage || !el('win').hidden) return;
  const move = { ArrowLeft: [-32, 0], ArrowRight: [32, 0], ArrowUp: [0, -32], ArrowDown: [0, 32] }[event.key];
  if (move) setView(view.zoom, view.x + move[0], view.y + move[1]);
  else if (event.key === '+' || event.key === '=') zoomAt(1.25);
  else if (event.key === '-') zoomAt(0.8);
  else return;
  resetGesture();
  event.preventDefault();
});
scene.addEventListener('load', fit);
new ResizeObserver(fit).observe(stage);
el('menu-play').addEventListener('click', () => {
  showGame();
  (editing ? nameInput : stage).focus({ preventScroll: true });
});
el('menu-back').addEventListener('click', showMenu);
el('menu-settings').addEventListener('click', () => el('settings').showModal());
el('fullscreen').addEventListener('click', async () => {
  const status = el('settings-status');
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else await document.documentElement.requestFullscreen();
    status.textContent = '';
    el('settings').close();
  } catch {
    status.textContent = 'Este navegador no pudo activar la pantalla completa.';
  }
});
for (const id of ['menu-upload', 'game-upload']) {
  el(id).addEventListener('click', () => el('upload').click());
}
el('fit').addEventListener('click', fit);
el('in').addEventListener('click', () => { resetGesture(); zoomAt(1.25); });
el('out').addEventListener('click', () => { resetGesture(); zoomAt(0.8); });
el('edit').addEventListener('click', () => setMode(true));
el('replay').addEventListener('click', () => setMode(false));
el('replay-win').addEventListener('click', () => setMode(false));
el('demo').addEventListener('click', () => loadBoard(demo));
el('custom').addEventListener('click', () => { if (customBoard) loadBoard(customBoard); });
el('upload').addEventListener('change', (event) => {
  const [file] = event.target.files;
  event.target.value = '';
  if (!file) return;
  if (file.size > 20 * 1024 * 1024) { showNotice('Elige una imagen de hasta 20 MB.'); return; }
  loadBoard({ title: file.name.replace(/\.[^.]+$/, '').slice(0, 80) || 'Mi escena', file, targets: [] }, true);
});
el('play').addEventListener('click', () => {
  if (!board.targets.length) return;
  setMode(false);
  if (board.file) {
    customBoard = { ...board, targets: board.targets.map((target) => ({ ...target })) };
    el('custom').hidden = false;
    savedScene(customBoard).catch(() => showNotice('Puedes jugar ahora, pero el navegador no pudo guardar la escena.'));
  }
});
el('camera').addEventListener('click', () => { if (tracker) stopCamera(); else startCamera(); });
deviceSelect.addEventListener('change', () => {
  if (!cameraReady) return;
  cameraId = deviceSelect.value;
  startCamera();
});
window.addEventListener('pagehide', () => stopCamera());
document.addEventListener('visibilitychange', resetGesture);

loadBoard(demo);
savedScene().then((stored) => {
  if (!stored?.file || !stored.targets?.length) return;
  customBoard = stored;
  el('custom').hidden = false;
}).catch(() => {});
