function openArchive() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('mandatin-archivo-perdido', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('scenes');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function savedScene(value) {
  const db = await openArchive();
  try {
    const write = value !== undefined;
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction('scenes', write ? 'readwrite' : 'readonly');
      const scenes = transaction.objectStore('scenes');
      const request = write ? scenes.put(value, 'custom') : scenes.get('custom');
      transaction.oncomplete = () => resolve(request.result);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    db.close();
  }
}
