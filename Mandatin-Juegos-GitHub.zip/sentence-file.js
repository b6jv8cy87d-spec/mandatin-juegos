import { cleanSentence, isValidSentence } from './sentence-engine.js';

export const MAX_SENTENCES = 300;
export const MAX_FILE_BYTES = 5 * 1024 * 1024;
const key = value => String(value ?? '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');

export function parseSentenceWorkbook(XLSX, data, filename) {
  if (data.byteLength > MAX_FILE_BYTES) throw new Error('El archivo supera los 5 MB.');
  const excel = /\.xlsx$/i.test(filename), csv = /\.csv$/i.test(filename);
  if (!excel && !csv) throw new Error('Elige un archivo Excel .xlsx o CSV UTF-8.');
  let input = data;
  if(excel && (new Uint8Array(data)[0]!==80 || new Uint8Array(data)[1]!==75)) throw new Error('El archivo no es un Excel .xlsx válido. Guárdalo de nuevo desde Excel.');
  if(csv) {
    const bytes=new Uint8Array(data);
    const encoding=bytes[0]===255 && bytes[1]===254?'utf-16le':bytes[0]===254 && bytes[1]===255?'utf-16be':'utf-8';
    try { input=new TextDecoder(encoding,{fatal:true}).decode(bytes); }
    catch { throw new Error('Guarda el CSV como CSV UTF-8 en Excel para conservar las tildes.'); }
  }
  let book;
  try { book=XLSX.read(input,{type:excel?'array':'string',raw:true,cellFormula:true,sheetRows:2001}); }
  catch { throw new Error('No pude leer el archivo. Comprueba que no tenga contraseña y vuelve a guardarlo como .xlsx.'); }
  const name=book.SheetNames.find(n=>key(n)==='oraciones') || book.SheetNames[0];
  const sheet=book.Sheets[name];
  if(!sheet?.['!ref']) throw new Error('La hoja está vacía. Usa la plantilla de oraciones.');
  const range=XLSX.utils.decode_range(sheet['!fullref'] || sheet['!ref']);
  if(range.e.r>=2000) throw new Error('Usa una hoja de hasta 2000 filas y un máximo de 300 oraciones.');
  const headers=Array.from({length:Math.min(range.e.c+1,32)},(_,c)=>key(sheet[XLSX.utils.encode_cell({r:0,c})]?.v));
  const columns=headers.map((h,c)=>h==='oracion'?c:-1).filter(c=>c>=0);
  if(columns.length!==1) throw new Error('La fila 1 debe tener una sola columna «Oración». Puedes usar la plantilla.');
  const sentenceColumn=columns[0];
  const contextColumn=headers.findIndex(h=>['contexto','pregunta','pregunta o contexto'].includes(h));
  const result=[];
  for(let r=1;r<=range.e.r;r++) {
    const cells=[sentenceColumn,contextColumn].map(c=>c<0?null:sheet[XLSX.utils.encode_cell({r,c})]);
    if(cells.some(cell=>cell?.f)) throw new Error(`Fila ${r+1}: usa texto escrito, no fórmulas.`);
    if(cells.some(cell=>cell?.t==='e')) throw new Error(`Fila ${r+1}: hay una celda con error.`);
    const [sentence,context]=cells.map(cell=>cleanSentence(cell?.v));
    if(!sentence && !context) continue;
    if(!isValidSentence(sentence)) throw new Error(`Fila ${r+1}: la oración debe tener entre 3 y 12 palabras y hasta 180 caracteres.`);
    if(context.length>300) throw new Error(`Fila ${r+1}: el contexto supera los 300 caracteres.`);
    result.push({sentence,context});
    if(result.length>MAX_SENTENCES) throw new Error('El banco admite un máximo de 300 oraciones.');
  }
  if(!result.length) throw new Error('No hay oraciones. Escríbelas debajo de los encabezados.');
  return result;
}

export function mergeSentenceBank(current, incoming, replace=false) {
  const next=replace?[...incoming]:[...current,...incoming];
  if(next.length>MAX_SENTENCES) throw new Error('El banco completo no puede superar 300 oraciones. Usa «Reemplazar banco» o reduce el archivo.');
  return next;
}
