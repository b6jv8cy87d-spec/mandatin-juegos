export class DwellSelector {
  constructor(duration = 5000) { this.duration = duration; this.reset(); }
  reset() { this.target = null; this.since = 0; this.fired = false; }
  update(target, now) {
    if (!target) { this.reset(); return { progress: 0, select: false }; }
    if (target !== this.target) { this.target = target; this.since = now; this.fired = false; }
    const progress = Math.min(1, (now - this.since) / this.duration);
    const select = progress === 1 && !this.fired;
    if (select) this.fired = true;
    return { progress, select };
  }
}
