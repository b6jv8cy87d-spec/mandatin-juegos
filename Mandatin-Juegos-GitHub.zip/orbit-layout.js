// Fractions of the complete illustrated screen, including a margin for each pickup.
const covered = [
  [0, 0, .82, .18],       // energy / level HUD
  [.815, 0, 1, .38],     // camera and tracking console
  [.79, .79, 1, 1],      // pause and camera buttons
  [0, .93, .25, 1],      // sound and details buttons
  [.22, .15, .73, .26],  // encounter announcement
];

export function pickupVisible(x, y, radius, width, height) {
  const margin = radius + 8;
  if (x < margin || y < margin || x > width-margin || y > height-margin) return false;
  return !covered.some(([left,top,right,bottom]) =>
    x+margin > left*width && x-margin < right*width &&
    y+margin > top*height && y-margin < bottom*height);
}
