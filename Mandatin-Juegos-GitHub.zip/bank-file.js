import { validQuestion } from './question-bank.js';

export const CSV_TEMPLATE = '\uFEFFtipo;pregunta;A;B;C;D;correcta;respuesta\r\nalternativas;¿Cuál es la capital de Chile?;Santiago;Lima;Quito;Bogotá;A;\r\nabierta;¿Cómo se llama nuestro planeta?;;;;;;Tierra\r\n';

function csvRows(text) {
  const first = text.split(/\r?\n/)[0];
  const delimiter = first.includes(';') ? ';' : first.includes('\t') ? '\t' : ',';
  const rows = []; let row = [], field = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') { field += '"'; i++; }
      else if (quoted || !field) quoted = !quoted;
      else field += c;
    } else if (!quoted && (c === delimiter || c === '\n' || c === '\r')) {
      row.push(field); field = '';
      if (c !== delimiter) {
        if (row.some(v => v.trim())) rows.push(row);
        row = [];
        if (c === '\r' && text[i + 1] === '\n') i++;
      }
    } else field += c;
  }
  if (quoted) throw new Error('Hay comillas sin cerrar en el CSV.');
  row.push(field); if (row.some(v => v.trim())) rows.push(row);
  return rows;
}

export function parseBankFile(text, filename) {
  if (text.length > 8 * 1024 * 1024) throw new Error('El banco supera los 8 MB.');
  text = text.replace(/^\uFEFF/, '');
  let questions;
  if (/\.json$/i.test(filename)) {
    const data = JSON.parse(text);
    questions = Array.isArray(data) ? data : data.questions;
  } else if (/\.(csv|tsv)$/i.test(filename)) {
    const rows = csvRows(text);
    const header = (rows.shift() || []).map(v => v.trim().toLowerCase());
    if (!['tipo','pregunta','a','b','c','d','correcta','respuesta'].every(h => header.includes(h))) {
      throw new Error('Usa la plantilla CSV: tipo, pregunta, A, B, C, D, correcta y respuesta.');
    }
    questions = rows.map((row) => {
      const get = key => (row[header.indexOf(key)] || '').trim();
      if (['abierta', 'open'].includes(get('tipo').toLowerCase())) {
        return { type: 'open', prompt: get('pregunta'), answer: get('respuesta') };
      }
      if (!['alternativas','multiple'].includes(get('tipo').toLowerCase())) throw new Error('En tipo escribe alternativas o abierta.');
      const answer = get('correcta').toUpperCase();
      return { type: 'multiple', prompt: get('pregunta'), options: ['a','b','c','d'].map(get),
        correct: /^[1-4]$/.test(answer) ? Number(answer) - 1 : 'ABCD'.indexOf(answer.length === 1 ? answer : '?') };
    });
  } else throw new Error('Elige un archivo JSON o CSV exportado desde Excel.');
  if (!Array.isArray(questions) || !questions.length || questions.length > 300) {
    throw new Error('El banco debe contener entre 1 y 300 preguntas.');
  }
  return questions.map((q, i) => {
    if (!validQuestion(q)) throw new Error(`Revisa la pregunta ${i + 1}: faltan datos o la respuesta/imagen no es válida.`);
    if(q.prompt.trim().length>240 || (q.type==='open' ? q.answer.trim().length>240 : q.options.some(v=>v.trim().length>100)) || (q.image && q.image.length>600000)) throw new Error(`La pregunta ${i+1} es demasiado larga o su imagen es muy grande.`);
    return { type: q.type === 'open' ? 'open' : 'multiple', prompt: q.prompt.trim(),
      ...(q.type === 'open' ? { answer: q.answer.trim() } : { options: q.options.map(v => v.trim()), correct: q.correct }),
      ...(q.image ? { image: q.image } : {}) };
  });
}

export function exportBankFile(questions) {
  return JSON.stringify({ format: 'mandatin-bank', version: 1, questions }, null, 2);
}
