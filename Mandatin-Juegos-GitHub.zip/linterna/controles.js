const clamp = (value) => Math.min(1, Math.max(0, value));
const distance = (a, b, aspect = 1) => Math.hypot((a.x - b.x) * aspect, a.y - b.y);

export function handsByPlayer(hands, players, mirrored, previous = []) {
  const slots = Array(players).fill(null);
  for (const hand of hands) {
    const wrist = hand[0];
    if (!wrist || !hand[8] || !hand[17]) continue;
    const x = mirrored ? 1 - wrist.x : wrist.x;
    // Assign by wrist so the same fist stays with its player's camera lane.
    const index = players === 1 || x < 0.5 ? 0 : 1;
    const candidate = slots[index];
    const reference = previous[index] || { x: mirrored ? 1 - (index + 0.5) / players : (index + 0.5) / players, y: 0.5 };
    if (!candidate || distance(wrist, reference) < distance(candidate[0], reference)) slots[index] = hand;
  }
  return slots;
}

export function handInput(hand, { players, index, mirrored, aspect, pinching }) {
  const tip = hand[8];
  const palm = Math.max(0.001, distance(hand[0], hand[9], aspect), distance(hand[5], hand[17], aspect));
  const curled = [5, 9, 13, 17].map((base) =>
    distance(hand[base + 3], hand[0], aspect) < distance(hand[base + 1], hand[0], aspect) * 0.98 &&
    distance(hand[base + 3], hand[base], aspect) < distance(hand[base + 1], hand[base], aspect) * 1.15
  );
  const grip = curled[0] && curled.filter(Boolean).length >= 3;
  const center = [0, 5, 9, 13, 17].reduce((sum, i) => ({
    x: sum.x + hand[i].x / 5,
    y: sum.y + hand[i].y / 5
  }), { x: 0, y: 0 });
  const x = mirrored ? 1 - center.x : center.x;
  const pinchRatio = distance(hand[4], tip, aspect) / palm;
  return {
    // Map the palm's comfortable movement area onto the full image.
    point: { x: clamp((x * players - index - 0.09) / 0.82), y: clamp((center.y - 0.16) / 0.68) },
    motion: { x: center.x, y: center.y / aspect },
    grip,
    // A tucked thumb in a closed fist must not accidentally relight the torch.
    pinch: !grip && pinchRatio < (pinching ? 0.46 : 0.31),
    pinchReleased: !grip && pinchRatio > 0.52
  };
}

export class Flashlight {
  constructor() { this.reset(); }

  reset() {
    this.burnedOut = false;
    this.point = null;
    this.release();
  }

  release() {
    this.present = false;
    this.pinching = false;
    this.sample = null;
    this.fastFrames = 0;
    this.relampAt = -Infinity;
    this.resetPinches();
  }

  resetPinches() {
    this.pinchCount = 0;
    this.pinchSince = null;
    this.openSince = null;
    this.pinchArmed = false;
    this.closedConfirmed = false;
  }

  ignite(now) {
    this.burnedOut = false;
    this.fastFrames = 0;
    this.relampAt = now;
    this.resetPinches();
  }

  updatePinches(pinch, released, grip, now) {
    if (pinch) {
      this.openSince = null;
      if (this.pinchArmed) {
        this.pinchSince ??= now;
        if (now - this.pinchSince >= 70) this.closedConfirmed = true;
      }
      return;
    }
    if (released) {
      this.openSince ??= now;
      if (now - this.openSince >= 70) {
        if (this.closedConfirmed) {
          this.pinchCount += 1;
          this.closedConfirmed = false;
          if (this.pinchCount === 2) this.ignite(now);
        }
        this.pinchArmed = true;
        this.pinchSince = null;
      }
      return;
    }
    // Allow the fingers to travel through the gap between close/open thresholds.
    this.openSince = null;
    this.pinchSince = null;
    if (grip) {
      this.closedConfirmed = false;
      this.pinchArmed = false;
    }
  }

  move({ point, motion = point, pinch = false, pinchReleased = false, grip = true }, now) {
    this.pinching = pinch;
    if (this.burnedOut) this.updatePinches(pinch, pinchReleased, grip, now);
    this.present = grip;
    if (!grip) {
      this.sample = null;
      this.fastFrames = 0;
      return;
    }

    const elapsed = this.sample ? now - this.sample.at : Infinity;
    if (elapsed >= 34) {
      if (elapsed <= 350 && now - this.relampAt > 170 && !this.burnedOut) {
        const speed = distance(motion, this.sample.motion) * 1000 / elapsed;
        this.fastFrames = speed >= 1.65 ? this.fastFrames + 1 : 0;
        if (this.fastFrames >= 2 || speed >= 3.1) {
          this.burnedOut = true;
          this.resetPinches();
        }
      } else {
        this.fastFrames = 0;
      }
      this.sample = { at: now, motion };
    }

    const prior = this.point;
    // Slight smoothing reduces the visible shake of the beam.
    this.point = !prior || elapsed > 350 ? point : {
      x: prior.x + (point.x - prior.x) * 0.78,
      y: prior.y + (point.y - prior.y) * 0.78
    };
  }

  get lit() { return this.present && !this.burnedOut; }
}
