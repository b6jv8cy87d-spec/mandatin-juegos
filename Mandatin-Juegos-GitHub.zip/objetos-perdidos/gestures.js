const midpoint = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
const mirror = ({ x, y }) => ({ x: 1 - x, y });

export class GestureReader {
  previous = [];

  reset() {
    this.previous = [];
  }

  read(landmarks, aspect) {
    const distance = (a, b) => Math.hypot((a.x - b.x) * aspect, a.y - b.y);
    const hands = landmarks.filter((hand) => hand.length >= 21).slice(0, 2);
    let candidates = [...this.previous];
    // Match both wrists together when the detector changes the order of its results.
    if (hands.length === 2 && candidates.length === 2) {
      const direct = distance(hands[0][0], candidates[0].wrist) + distance(hands[1][0], candidates[1].wrist);
      const swapped = distance(hands[0][0], candidates[1].wrist) + distance(hands[1][0], candidates[0].wrist);
      if (swapped < direct) candidates.reverse();
    } else if (hands.length === 1 && candidates.length === 2) {
      candidates.sort((a, b) => distance(hands[0][0], a.wrist) - distance(hands[0][0], b.wrist));
    } else if (hands.length === 2 && candidates.length === 1 && distance(hands[1][0], candidates[0].wrist) < distance(hands[0][0], candidates[0].wrist)) {
      candidates = [null, candidates[0]];
    }
    this.previous = hands.map((hand, i) => {
      const wrist = hand[0];
      const palm = Math.max(0.001, distance(wrist, hand[9]), distance(hand[5], hand[17]));
      const previous = candidates[i];
      const wasPinching = previous?.pinch && distance(wrist, previous.wrist) < 0.24;
      const pinch = distance(hand[4], hand[8]) / palm < (wasPinching ? 0.47 : 0.33);
      return { wrist, pinch, center: midpoint(hand[4], hand[8]), hand };
    });
    const pinches = this.previous.filter((hand) => hand.pinch);
    if (pinches.length === 2) {
      const [a, b] = pinches.map((hand) => hand.center);
      return { mode: 'zoom', point: mirror(midpoint(a, b)), spread: Math.max(0.075, distance(a, b)) };
    }
    if (pinches.length === 1) {
      const hand = pinches[0];
      return { mode: 'pan', point: mirror(hand.center), wrist: hand.wrist };
    }
    const isExtended = (hand, base) => {
      const [mcp, pip, , tip] = hand.slice(base, base + 4);
      return distance(mcp, tip) > distance(mcp, pip) * 1.53 &&
        distance(hand[0], tip) > distance(hand[0], pip) * 1.06;
    };
    if (hands.length === 1 && isExtended(hands[0], 5) &&
        [9, 13, 17].filter((base) => !isExtended(hands[0], base)).length >= 2) {
      return { mode: 'point', point: mirror(hands[0][8]), wrist: hands[0][0] };
    }
    return { mode: hands.length ? 'ready' : 'idle' };
  }
}
