/* SheetJS CE 0.20.3, Apache-2.0. Loaded only when importing. */
importScripts('./vendor/xlsx.mini.min.js');
self.onmessage=async ({data})=>{
  try {
    const {parseSentenceWorkbook}=await import('./sentence-file.js?v=excel1');
    if(data.action==='import') self.postMessage({sentences:parseSentenceWorkbook(XLSX,data.buffer,data.name)});
    else throw new Error('Operación no reconocida.');
  } catch(error) {self.postMessage({error:error.message || 'No pude procesar el archivo.'});}
};
