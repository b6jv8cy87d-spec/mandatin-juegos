import { clamp } from "./engine.js";

export const SAMPLE_W = 320;
export const SAMPLE_H = 180;
export const PAPER_GRACE = 450;
export const PRESETS = { fuchsia: { hue: 316, sat: .34, value: .24 }, cyan: { hue: 194, sat: .38, value: .29 } };

export function hueDistance(a, b) {
  return Math.abs((a - b + 540) % 360 - 180);
}

function pixelHSV(red, green, blue, out) {
  const high = Math.max(red, green, blue), low = Math.min(red, green, blue);
  const range = high - low;
  const sector = !range ? 0 : high === red ? (green - blue) / range :
    high === green ? 2 + (blue - red) / range : 4 + (red - green) / range;
  out.hue = (sector * 60 + 360) % 360;
  out.sat = high ? range / high : 0;
  out.value = high / 255;
}

export function samplePaper(data, x, y, expected) {
  const hsv = {};
  let u = 0, v = 0, sat = 0, value = 0, count = 0;
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
    const i = (clamp(y + dy, 0, SAMPLE_H - 1) * SAMPLE_W + clamp(x + dx, 0, SAMPLE_W - 1)) * 4;
    pixelHSV(data[i], data[i + 1], data[i + 2], hsv);
    if (hsv.sat < .32 || hsv.value < .24 || hueDistance(hsv.hue, expected.hue) > 50) continue;
    const angle = hsv.hue * Math.PI / 180;
    u += Math.cos(angle);
    v += Math.sin(angle);
    sat += hsv.sat;
    value += hsv.value;
    count++;
  }
  if (count < 20) return null;
  return {
    hue: (Math.atan2(v, u) * 180 / Math.PI + 360) % 360,
    sat: Math.max(.29, sat / count * .55),
    value: Math.max(.22, value / count * .52)
  };
}

const area = box => box.w * box.h;
const centerX = box => box.x + box.w / 2;
const centerY = box => box.y + box.h / 2;

function overlaps(first, second) {
  const w = Math.max(0, Math.min(first.x + first.w, second.x + second.w) - Math.max(first.x, second.x));
  const h = Math.max(0, Math.min(first.y + first.h, second.y + second.h) - Math.max(first.y, second.y));
  return w * h > .55 * Math.min(area(first), area(second));
}

export class PaperTracker {
  constructor() {
    this.reset();
  }

  reset() {
    this.anchor = null;
    this.profile = null;
    this.box = null;
    this.pending = null;
    this.samples = 0;
    this.lastSeen = -Infinity;
    this.stableSince = null;
    this.visible = false;
  }

  select(x, y, profile) {
    this.reset();
    this.anchor = { x, y };
    this.profile = profile;
  }

  update(candidates, now, reserved) {
    this.visible = false;
    if (!this.anchor) return;
    const previous = this.box;
    const gap = now - this.lastSeen;
    let winner = null, best = -Infinity;
    for (const box of candidates) {
      if (reserved && overlaps(box, reserved)) continue;
      let score = box.fill;
      if (!previous) {
        if (this.anchor.x < box.x || this.anchor.x > box.x + box.w ||
            this.anchor.y < box.y || this.anchor.y > box.y + box.h) continue;
      } else {
        const ratio = area(box) / area(previous);
        const distance = Math.hypot(centerX(box) - centerX(previous), centerY(box) - centerY(previous));
        if (ratio < .4 || ratio > 2.5 || distance > 30 + Math.min(gap, 2500) * .17) continue;
        score -= distance * .012 + Math.abs(Math.log(ratio)) * .5;
      }
      if (score > best) { best = score; winner = box; }
    }
    if (!winner) {
      this.pending = null;
      this.samples = 0;
      this.stableSince = null;
      return;
    }
    if (!previous || gap > 220) {
      if (!this.pending || Math.hypot(winner.x - this.pending.x, winner.y - this.pending.y) > 25) this.samples = 0;
      this.pending = winner;
      if (++this.samples < 3) return;
    }
    const smooth = previous && gap < 220 ? .68 : 1;
    this.box = smooth === 1 ? winner : {
      x: previous.x + (winner.x - previous.x) * smooth,
      y: previous.y + (winner.y - previous.y) * smooth,
      w: previous.w + (winner.w - previous.w) * smooth,
      h: previous.h + (winner.h - previous.h) * smooth
    };
    this.visible = true;
    this.lastSeen = now;
    this.stableSince ??= now;
  }

  ready(now) {
    return this.visible && now - this.lastSeen < 200 && this.stableSince !== null && now - this.stableSince >= 550;
  }

  platform(now) {
    if (!this.box || now - this.lastSeen > PAPER_GRACE) return null;
    const { x, y, w, h } = this.box;
    return { x: x * 4, y: y * 4, w: w * 4, h: h * 4 };
  }
}

export class PaperDetector {
  constructor() {
    this.hue = new Uint16Array(SAMPLE_W * SAMPLE_H);
    this.sat = new Uint8Array(this.hue.length);
    this.value = new Uint8Array(this.hue.length);
    this.mask = new Uint8Array(this.hue.length);
    this.queue = new Int32Array(this.hue.length);
  }

  read(data) {
    const hsv = {};
    for (let i = 0; i < this.hue.length; i++) {
      const offset = i * 4;
      pixelHSV(data[offset], data[offset + 1], data[offset + 2], hsv);
      this.hue[i] = hsv.hue;
      this.sat[i] = hsv.sat * 255;
      this.value[i] = hsv.value * 255;
    }
  }

  find(profile) {
    const { hue, sat, value, mask, queue } = this;
    for (let i = 0; i < mask.length; i++) {
      mask[i] = sat[i] >= profile.sat * 255 && value[i] >= profile.value * 255 &&
        hueDistance(hue[i], profile.hue) <= 34 ? 1 : 0;
    }
    const boxes = [];
    for (let i = 0; i < mask.length; i++) {
      if (!mask[i]) continue;
      let start = 0, end = 1, left = SAMPLE_W, right = 0, top = SAMPLE_H, bottom = 0;
      mask[i] = 0;
      queue[0] = i;
      const visit = index => {
        if (mask[index]) { mask[index] = 0; queue[end++] = index; }
      };
      while (start < end) {
        const index = queue[start++];
        const x = index % SAMPLE_W, y = (index / SAMPLE_W) | 0;
        left = Math.min(left, x); right = Math.max(right, x);
        top = Math.min(top, y); bottom = Math.max(bottom, y);
        if (x > 0) visit(index - 1);
        if (x < SAMPLE_W - 1) visit(index + 1);
        if (y > 0) visit(index - SAMPLE_W);
        if (y < SAMPLE_H - 1) visit(index + SAMPLE_W);
      }
      const w = right - left + 1, h = bottom - top + 1;
      const fill = end / (w * h);
      if (end >= 32 && end < 9000 && Math.min(w, h) >= 6 &&
          Math.min(w, h) / Math.max(w, h) >= .55 && fill >= .63) {
        boxes.push({ x: left, y: top, w, h, fill });
      }
    }
    return boxes;
  }
}
