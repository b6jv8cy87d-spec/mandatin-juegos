/**
 * Finger Dodge Game Engine
 */

import { OrbitRenderer } from './orbit-renderer.js?v=eclipse3';
import { pickupVisible } from './orbit-layout.js';
import { OrbitEncounter, ENERGY_PER_QUESTION } from './orbit-encounter.js?v=eclipse3';
export class Game {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext("2d");

    // Configurable Game Constants
    this.config = {
      // Dimensions
      width: 800,
      height: 450,

      // Player
      playerRadius: 19,
      smoothingFactor: 0.38,      // Lerp coefficient at 60 FPS
      stabilityThreshold: 1.0,   // Dead-zone (pixels) to prevent jitter

      // Coins
      coinRadius: 13,
      coinScoreValue: 1,

      // Obstacles
      baseObstacleSpawnInterval: 2200, // ms
      minObstacleSpawnInterval: 1300,  // ms
      baseObstacleSpeed: 90,          // px/sec
      maxObstacleSpeed: 420,          // px/sec
      minObstacleRadius: 14,
      maxObstacleRadius: 27,

      // Difficulty Scaling
      gracePeriod: 10000,             // 10 seconds of slow start
      speedIncreasePerCoin: 8,        // px/sec increase
      speedIncreasePerSecond: 1.5      // px/sec increase (after grace period)
    };

    // Game State variables
    this.player = {
      x: this.config.width / 2,
      y: this.config.height / 2,
      targetX: this.config.width / 2,
      targetY: this.config.height / 2,
      color: "#39ff14", // neon green
      glowColor: "rgba(57, 255, 20, 0.7)"
    };
    this.shipImage = new Image();
    this.shipImage.src = "./mandatin-nave.png";
    this.sideImage = new Image(); this.sideImage.src = './art/orbita/mandatin-lateral.webp';
    this.bossImage = new Image(); this.bossImage.src = './art/orbita/eclipse-lateral.webp';
    this.stars = Array.from({ length: 75 }, (_, i) => ({
      x: (i * 179 + 41) % 800,
      y: (i * 113 + 29) % 450,
      size: i % 9 === 0 ? 2 : 1
    }));
    this.starfieldCanvas = document.createElement("canvas");
    this.starfieldCanvas.width = this.config.width;
    this.starfieldCanvas.height = this.config.height;
    const starCtx = this.starfieldCanvas.getContext("2d");
    starCtx.fillStyle = "#081323";
    starCtx.fillRect(0, 0, this.config.width, this.config.height);
    starCtx.fillStyle = "#82b9d9";
    for (const star of this.stars) starCtx.fillRect(star.x, star.y, star.size, star.size);
    this.lightMode = false;
    this.lastDrawAt = 0;

    this.encounter = new OrbitEncounter();
    this.coins = [];
    this.obstacles = [];

    this.score = 0;
    this.highScore = parseInt(localStorage.getItem("fingerDodge_highScore")) || 0;
    this.level = 1;
    this.gameTime = 0; // total game time in ms
    this.safeUntil = 0;
    this.shieldUntil = 0;
    this.shieldPickup = null;
    this.nextShieldAt = 8000;
    this.isMuted = false;
    this.shieldsEnabled = true;
    this.debugMode = false;
    this.fps = 0;

    // Internal mechanics
    this.lastTime = 0;
    this.obstacleSpawnTimer = 0;
    this.currentObstacleSpeedMultiplier = 1.0;
    this.audioCtx = null;

    // FPS counter helper variables
    this.fpsUpdateTimer = 0;
    this.fpsFrameCount = 0;

    // Set fixed logical size for aspect ratio preservation
    this.canvas.width = this.config.width;
    this.canvas.height = this.config.height;
    if (window.Phaser) this.renderer = new OrbitRenderer(this);
  }

  /**
   * Initializes or resumes the Web Audio API context
   */
  initAudio() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (this.audioCtx.state === "suspended") {
      this.audioCtx.resume().catch(() => {});
    }
  }

  /**
   * Toggle mute state
   */
  toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  setLightMode(enabled) {
    this.lightMode = Boolean(enabled);
    this.renderer?.setLightMode(this.lightMode);
    this.lastDrawAt = 0;
  }

  /**
   * Dynamic Audio Synthesizer (Zero asset dependencies)
   * @param {string} type - 'coin', 'gameover', 'levelUp', 'countdown', 'countdownStart'
   */
  playSound(type) {
    if (this.isMuted) return;

    try {
      this.initAudio();
      if (!this.audioCtx) return;
      const now=this.audioCtx.currentTime;
      const notes={flyby:[110,147,165],battleStart:[165,165,220,330],shot:[520,180],hit:[160,100],battleWon:[392,523,659,784,1046],question:[587,784,1175],shield:[392,587,880,1175],coin:[660,990,1320],levelUp:[392,494,587,784],wrong:[240,200],gameover:[330,247,165,110],countdown:[440],countdownStart:[523,784,1046]}[type]||[440];
      notes.forEach((frequency,i)=>{
        const start=now+i*.085, duration=type==='gameover'?.38:type==='shot'?.12:.24;
        const osc=this.audioCtx.createOscillator(),gain=this.audioCtx.createGain();
        osc.type=['gameover','flyby','battleStart','shot'].includes(type)?'triangle':'sine';osc.frequency.setValueAtTime(frequency,start);
        if(type==='shot')osc.frequency.exponentialRampToValueAtTime(70,start+duration);
        gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(.10,start+.012);gain.gain.exponentialRampToValueAtTime(.001,start+duration);
        osc.connect(gain);gain.connect(this.audioCtx.destination);osc.start(start);osc.stop(start+duration+.02);
        osc.onended=()=>{osc.disconnect();gain.disconnect();};
      });
    } catch (e) { console.warn('Audio unavailable',e); }
  }

  /**
   * Resets all game states for a new match
   */
  reset() {
    this.player.x = this.config.width / 2;
    this.player.y = this.config.height / 2;
    this.player.targetX = this.config.width / 2;
    this.player.targetY = this.config.height / 2;

    this.coins = [];
    this.obstacles = [];
    this.score = 0;
    this.level = 1;
    this.gameTime = 0;
    this.safeUntil = 0;
    this.shieldUntil = 0;
    this.shieldPickup = null;
    this.nextShieldAt = 8000;
    this.encounter.reset();
    this.bossShots = 0;
    this.lastTime = 0;
    this.obstacleSpawnTimer = 0;
    this.currentObstacleSpeedMultiplier = 1.0;

    // Spawn initial coin
    this.spawnCoin();
  }

  /**
   * Set finger target coordinates received from hand tracker
   * @param {Object} coords - Normalized {x, y}
   */
  setTargetPosition(coords) {
    if (!coords) return;
    // Map normalized coordinates [0, 1] to canvas scale
    this.player.targetX = coords.x * this.config.width;
    this.player.targetY = coords.y * this.config.height;
  }

  /**
   * Spawns a coin at a safe random position
   */
  spawnCoin() {
    let x, y;
    let isSafe = false;
    let attempts = 0;

    const minDistanceFromPlayer = 180;
    const padding = 30;

    while (!isSafe && attempts < 100) {
      attempts++;
      x = padding + Math.random() * (this.config.width - padding * 2);
      y = padding + Math.random() * (this.config.height - padding * 2);

      if (!pickupVisible(x,y,this.config.coinRadius,this.config.width,this.config.height)) continue;

      // Calculate distance to player
      const distToPlayer = Math.hypot(x - this.player.x, y - this.player.y);
      if (distToPlayer < minDistanceFromPlayer) continue;

      // Calculate distance to obstacles
      let distToObstacleOk = true;
      for (const obs of this.obstacles) {
        const dist = Math.hypot(x - obs.x, y - obs.y);
        if (dist < obs.radius + this.config.coinRadius + 30) {
          distToObstacleOk = false;
          break;
        }
      }

      if (distToObstacleOk) {
        isSafe = true;
      }
    }

    if (!isSafe) {
      // A deterministic fallback also works when random candidates repeatedly hit the UI.
      const candidates = [];
      for (let cy=30;cy<this.config.height;cy+=24) for(let cx=30;cx<this.config.width;cx+=24) {
        if (!pickupVisible(cx,cy,this.config.coinRadius,this.config.width,this.config.height)) continue;
        if (this.obstacles.some(o=>Math.hypot(cx-o.x,cy-o.y)<o.radius+this.config.coinRadius+30)) continue;
        candidates.push({x:cx,y:cy,distance:Math.hypot(cx-this.player.x,cy-this.player.y)});
      }
      candidates.sort((a,b)=>b.distance-a.distance);
      if (!candidates.length) { this.coins=[]; return; }
      ({x,y}=candidates[0]);
    }
    this.coins = [{
      x,
      y,
      radius: this.config.coinRadius,
      pulseState: 0,
      color: "#61f59a",
      glowColor: "rgba(83, 255, 166, 0.8)"
    }];
  }

  /**
   * Spawns an obstacle off-screen moving towards a random direction
   */
  spawnShield() {
    for(let attempt=0;attempt<60;attempt++) {
      const p={x:35+Math.random()*Math.max(1,this.config.width-70),y:35+Math.random()*Math.max(1,this.config.height-70),radius:18,expires:this.gameTime+12000};
      if(!pickupVisible(p.x,p.y,p.radius,this.config.width,this.config.height))continue;
      if(Math.hypot(p.x-this.player.x,p.y-this.player.y)<100)continue;
      if([...this.coins,...this.obstacles].some(o=>Math.hypot(p.x-o.x,p.y-o.y)<o.radius+60))continue;
      this.shieldPickup=p;return;
    }
  }

  spawnObstacle() {
    const radius = this.config.minObstacleRadius + Math.random() * (this.config.maxObstacleRadius - this.config.minObstacleRadius);

    // Determine spawn wall: 0 = Top, 1 = Right, 2 = Bottom, 3 = Left
    const wall = Math.floor(Math.random() * 4);
    let x, y;
    let vx, vy;

    // Scale speed multiplier with level and elapsed time
    const levelMult = 1.0 + Math.min(this.level - 1, 16) * 0.065;
    const speed = (this.config.baseObstacleSpeed + Math.random() * 60) * levelMult * this.currentObstacleSpeedMultiplier;
    const clampedSpeed = Math.min(speed, this.config.maxObstacleSpeed);

    // Random target angle centered towards game area to guarantee it crosses the screen
    const targetX = this.config.width / 4 + Math.random() * (this.config.width / 2);
    const targetY = this.config.height / 4 + Math.random() * (this.config.height / 2);

    switch (wall) {
      case 0: // Top
        x = Math.random() * this.config.width;
        y = -radius;
        break;
      case 1: // Right
        x = this.config.width + radius;
        y = Math.random() * this.config.height;
        break;
      case 2: // Bottom
        x = Math.random() * this.config.width;
        y = this.config.height + radius;
        break;
      case 3: // Left
        x = -radius;
        y = Math.random() * this.config.height;
        break;
    }

    // Calculate velocity vector pointing to targets
    const angle = Math.atan2(targetY - y, targetX - x);
    vx = Math.cos(angle) * clampedSpeed;
    vy = Math.sin(angle) * clampedSpeed;

    const tint = [0xc99a72,0xffae68,0x96c681][Math.floor(Math.random()*3)];
    this.obstacles.push({
      tint,
      x,
      y,
      vx,
      vy,
      radius,
      rotation: Math.random() * Math.PI * 2,
      spin: (Math.random() - 0.5) * 1.5,
      color: "#fa855d",
      glowColor: "rgba(255, 102, 74, 0.4)"
    });
  }

  /**
   * Updates game entity positions, difficulty, and checks collisions
   * @param {number} timestamp - Current high-res timestamp
   * @returns {string|null} - 'gameover' if collided, 'coin' if coin collected, or null
   */
  update(timestamp) {
    if (!this.lastTime) {
      this.lastTime = timestamp;
      return null;
    }

    // Delta time in seconds
    let dt = (timestamp - this.lastTime) / 1000;
    this.lastTime = timestamp;

    // Clamp delta time to avoid huge updates if tab is frozen
    if (dt > 0.1) dt = 0.1;

    // Increment game timer
    this.gameTime += dt * 1000;

    // Track FPS
    this.updateFPS(dt);

    // 1. Update Player position with Lerp smoothing & Dead-zone
    const dx = this.player.targetX - this.player.x;
    const dy = this.player.targetY - this.player.y;
    const dist = Math.hypot(dx, dy);

    if (dist > this.config.stabilityThreshold) {
      // Keep the same response time on 15 FPS tablets and 60 FPS desktops.
      const frameAdjustedSmoothing = 1 - Math.pow(
        1 - this.config.smoothingFactor,
        Math.min(dt, 0.1) * 60
      );
      this.player.x += dx * frameAdjustedSmoothing;
      this.player.y += dy * frameAdjustedSmoothing;
    }

    // Clamp player to canvas boundaries
    const pr = this.config.playerRadius;
    // Keep the artwork inside the screen without enlarging its forgiving hit circle.
    const visualX = this.encounter.battling ? 54 : 45;
    this.player.x = Math.max(visualX, Math.min(this.config.width-visualX, this.player.x));
    this.player.y = Math.max(45, Math.min(this.config.height-45, this.player.y));

    this.currentObstacleSpeedMultiplier = 1;

    const wasBattling = this.encounter.battling;
    const encounterEvents = this.encounter.step(dt * 1000, this.gameTime);
    for (const event of encounterEvents) {
      if (['flyby','battleStart','battleWon'].includes(event)) this.playSound(event);
      if (event === 'shot') this.spawnBossAttack(false);
      if (event === 'rock') this.spawnBossAttack(true);
      if (event === 'battleWon') { this.obstacles = []; this.level++; }
      if (event === 'flightResumed') {
        this.safeUntil = this.gameTime + 1800;
        this.obstacleSpawnTimer = 0; this.spawnCoin();
      }
    }
    if (!wasBattling && !this.encounter.battling) {
      if (!this.coins.length) this.spawnCoin();
      this.obstacleSpawnTimer += dt * 1000;
      const interval = Math.max(this.config.minObstacleSpawnInterval,
        this.config.baseObstacleSpawnInterval - Math.min(this.level - 1, 16) * 60);
      if (this.obstacleSpawnTimer >= interval) { this.obstacleSpawnTimer = 0; this.spawnObstacle(); }
    }

    // 4. Update Obstacles position & remove offscreen ones
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      obs.x += obs.vx * dt;
      obs.y += obs.vy * dt;
      obs.rotation += obs.spin * dt;

      // Padding boundary to allow obstacles to leave fully
      const bound = obs.radius * 2;
      if (
        obs.x < -bound ||
        obs.x > this.config.width + bound ||
        obs.y < -bound ||
        obs.y > this.config.height + bound
      ) {
        this.obstacles.splice(i, 1);
      }
    }

    // 5. Update Coins (e.g. update pulser scale animations)
    for (const coin of this.coins) {
      coin.pulseState += dt * 6; // frequency of pulse
    }

    if(this.shieldsEnabled && !this.encounter.battling) {
      if(this.shieldPickup && this.gameTime>=this.shieldPickup.expires) this.shieldPickup=null;
      if(!this.shieldPickup && this.gameTime>=this.nextShieldAt) {
        this.spawnShield();this.nextShieldAt=this.gameTime+18000;
      }
      if(this.shieldPickup && Math.hypot(this.player.x-this.shieldPickup.x,this.player.y-this.shieldPickup.y)<pr+this.shieldPickup.radius) {
        this.shieldUntil=this.gameTime+5000;
        this.shieldPickup=null;
        this.playSound('shield');
      }
    } else { this.shieldPickup=null;this.shieldUntil=0; }

    // 6. Collision Detection (Circle-Circle)

    // Player vs Coin
    let coinCollected = false;
    for (let i = 0; i < this.coins.length; i++) {
      const coin = this.coins[i];
      const distToCoin = Math.hypot(coin.x - this.player.x, coin.y - this.player.y);
      if (distToCoin < pr + coin.radius) {
        // Collect!
        this.score += this.config.coinScoreValue;
        this.playSound("coin");
        coinCollected = true;


      }
    }

    if (coinCollected) {
      this.spawnCoin();
      if (!this.questionMode && this.score % (ENERGY_PER_QUESTION * 2) === 0) this.startBattle();
    }

    // Player vs Obstacles (Game Over check)
    for (const obs of this.obstacles) {
      const distToObs = Math.hypot(obs.x - this.player.x, obs.y - this.player.y);
      if (this.gameTime >= (obs.armedAt || 0) && this.gameTime >= Math.max(this.safeUntil,this.shieldUntil) && distToObs < (pr + obs.radius - 2.5)) { // 2.5px overlap leeway for tight collision
        if (this.encounter.phase === 'battle' && ++this.encounter.hits < 3) {
          this.safeUntil = this.gameTime + 1500;
          this.obstacles = this.obstacles.filter(o => Math.hypot(o.x-this.player.x,o.y-this.player.y) > o.radius+90);
          this.playSound('hit');
          break;
        }
        this.playSound("gameover");

        // Check for new High Score
        let newHighScore = false;
        if (this.score > this.highScore) {
          this.highScore = this.score;
          localStorage.setItem("fingerDodge_highScore", this.highScore);
          newHighScore = true;
        }

        return "gameover";
      }
    }

    return coinCollected ? "coin" : null;
  }

  startBattle() {
    if (!this.encounter.start()) return;
    this.bossShots = 0;
    this.obstacles = []; this.coins = []; this.shieldPickup = null;
    this.player.x = this.player.targetX = this.config.width * .23;
    this.safeUntil = this.gameTime + 2800;
    this.playSound('flyby');
  }

  spawnBossAttack(rock) {
    const round = this.encounter.round;
    const x = this.config.width * .69;
    const y = rock ? 40 + Math.random() * Math.max(1, this.config.height - 80) : this.config.height * .48;
    const speed = Math.min(280, 145 + round * 18);
    // Aim once at the current position; projectiles never follow later movements.
    const angle = Math.atan2(this.player.y-y, this.player.x-x);
    this.bossShots = (this.bossShots || 0) + (rock ? 0 : 1);
    const angles = !rock && round >= 3 && this.bossShots % 3 === 0 ? [angle-.20,angle,angle+.20] : [angle];
    for (const direction of angles) {
      this.obstacles.push({ x, y, vx: Math.cos(direction)*speed*(rock?.75:1), vy: Math.sin(direction)*speed*(rock?.75:1),
        radius: rock ? 20 : 10, kind: rock ? 'rock' : 'bolt', tint: rock ? 0xc99a72 : 0xffffff,
        rotation: 0, spin: rock ? .5 : 0, armedAt: this.gameTime + 250 });
    }
    if (!rock) this.playSound('shot');
  }

  /**
   * Render loop containing all drawing methods
   */
  draw() {
    if (this.renderer?.ready) return;
    const now = performance.now();
    if (this.lightMode && now - this.lastDrawAt < 33) return;
    this.lastDrawAt = now;
    this.ctx.drawImage(this.starfieldCanvas, 0, 0);

    const e = this.encounter;
    if (this.bossImage.complete && this.bossImage.naturalWidth && (e.flyby || e.battling)) {
      const w = this.config.width * (e.battling ? .36 : 1.25), h = w * .58;
      const x = e.battling ? this.config.width*.80 : e.flyby.reverse ? this.config.width+w/2-e.flyby.progress*(this.config.width+w) : -w/2+e.flyby.progress*(this.config.width+w);
      this.ctx.save(); this.ctx.globalAlpha = e.battling ? 1 : .72;
      this.ctx.translate(x, e.battling ? this.config.height*.5 : this.config.height*.49);
      if (e.flyby && !e.flyby.reverse) this.ctx.scale(-1,1);
      this.ctx.drawImage(this.bossImage,-w/2,-h/2,w,h);this.ctx.restore();
    }
    if(this.shieldPickup) {
      this.ctx.fillStyle='#45bfff';this.ctx.beginPath();this.ctx.arc(this.shieldPickup.x,this.shieldPickup.y,18,0,Math.PI*2);this.ctx.fill();
      this.ctx.fillStyle='white';this.ctx.font='bold 18px sans-serif';this.ctx.fillText('S',this.shieldPickup.x-6,this.shieldPickup.y+6);
    }
    if(this.gameTime<this.shieldUntil) {
      this.ctx.strokeStyle='#78deff';this.ctx.lineWidth=3;this.ctx.beginPath();this.ctx.arc(this.player.x,this.player.y,47,0,Math.PI*2);this.ctx.stroke();
    }
    // 2. Draw Coins
    for (const coin of this.coins) {
      const scale = 1.0 + Math.sin(coin.pulseState) * 0.15; // Pulse animation
      const r = coin.radius * scale;

      this.ctx.shadowBlur = this.lightMode ? 0 : 18;
      this.ctx.shadowColor = coin.glowColor;

      // Energy crystal
      this.ctx.fillStyle = "rgba(90, 255, 168, 0.18)";
      this.ctx.beginPath();
      this.ctx.arc(coin.x, coin.y, r * 1.6, 0, 2 * Math.PI);
      this.ctx.fill();
      this.ctx.fillStyle = coin.color;
      this.ctx.beginPath();
      this.ctx.moveTo(coin.x, coin.y - r);
      this.ctx.lineTo(coin.x + r * 0.72, coin.y);
      this.ctx.lineTo(coin.x, coin.y + r);
      this.ctx.lineTo(coin.x - r * 0.72, coin.y);
      this.ctx.closePath();
      this.ctx.fill();
    }

    // 3. Draw Obstacles
    for (const obs of this.obstacles) {
      if (obs.kind === 'bolt') {
        this.ctx.fillStyle='#dd8cff'; this.ctx.beginPath();this.ctx.arc(obs.x,obs.y,obs.radius,0,Math.PI*2);this.ctx.fill();
        continue;
      }
      this.ctx.save();
      this.ctx.translate(obs.x, obs.y);
      this.ctx.rotate(obs.rotation);
      this.ctx.shadowBlur = this.lightMode ? 0 : 8;
      this.ctx.shadowColor = obs.glowColor;
      this.ctx.fillStyle = obs.tint ? "#"+obs.tint.toString(16).padStart(6,"0") : "#9e5048";
      this.ctx.strokeStyle = "#e68064";
      this.ctx.lineWidth = 2;
      this.ctx.beginPath();
      for (let i = 0; i < 9; i++) {
        const a = i * Math.PI * 2 / 9;
        const radius = obs.radius * (i % 3 === 0 ? 0.79 : 1);
        if (i === 0) this.ctx.moveTo(Math.cos(a) * radius, Math.sin(a) * radius);
        else this.ctx.lineTo(Math.cos(a) * radius, Math.sin(a) * radius);
      }
      this.ctx.closePath();
      this.ctx.fill();
      this.ctx.stroke();
      this.ctx.shadowBlur = 0;
      this.ctx.fillStyle = "#6c3740";
      this.ctx.beginPath();
      this.ctx.arc(-obs.radius * 0.25, -obs.radius * 0.16, obs.radius * 0.18, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    }

    // Mandatín's visible sprite is larger than its forgiving collision circle.
    if (this.shipImage.complete && this.shipImage.naturalWidth) {
      const side = this.encounter.battling && this.sideImage.complete && this.sideImage.naturalWidth;
      this.ctx.drawImage(side ? this.sideImage : this.shipImage, this.player.x - (side?46:36), this.player.y - 37, side?92:72, 72);
    } else {
      this.ctx.fillStyle = "#39bfe6";
      this.ctx.beginPath();
      this.ctx.arc(this.player.x, this.player.y, 22, 0, Math.PI * 2);
      this.ctx.fill();
    }

    // Reset shadow values for performance on UI elements
    this.ctx.shadowBlur = 0;
  }

  /**
   * Draws a futuristic dark blue grid on the background
   */
  drawSubtleGrid() {
    this.ctx.strokeStyle = "rgba(0, 240, 255, 0.035)";
    this.ctx.lineWidth = 1.0;

    const gridSize = 40;

    // Vertical grid lines
    for (let x = 0; x < this.config.width; x += gridSize) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, 0);
      this.ctx.lineTo(x, this.config.height);
      this.ctx.stroke();
    }

    // Horizontal grid lines
    for (let y = 0; y < this.config.height; y += gridSize) {
      this.ctx.beginPath();
      this.ctx.moveTo(0, y);
      this.ctx.lineTo(this.config.width, y);
      this.ctx.stroke();
    }
  }

  /**
   * FPS calculator utility
   */
  updateFPS(dt) {
    this.fpsFrameCount++;
    this.fpsUpdateTimer += dt;

    if (this.fpsUpdateTimer >= 0.5) { // update every 0.5s
      this.fps = Math.round(this.fpsFrameCount / this.fpsUpdateTimer);
      this.fpsFrameCount = 0;
      this.fpsUpdateTimer = 0;
    }
  }
}
