// Adaptive low-pass filter: stable at rest, responsive during intentional movement.
export class FingerFilter {
  reset() { this.point=null; this.raw=null; this.time=0; this.pending=null; }
  constructor() { this.reset(); }
  update(point, now) {
    if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y)) { this.reset(); return null; }
    const p={x:Math.max(0,Math.min(1,point.x)),y:Math.max(0,Math.min(1,point.y))};
    if(!this.point || now-this.time>350) { this.point=p;this.raw=p;this.time=now;return {...p}; }
    const distance=Math.hypot(p.x-this.raw.x,p.y-this.raw.y);
    // A single implausible jump is ignored; a confirmed new location is accepted.
    if(distance>.35 && (!this.pending || Math.hypot(p.x-this.pending.x,p.y-this.pending.y)>.12)) {
      this.pending=p; return {...this.point};
    }
    this.pending=null;
    const dt=Math.max(.008,Math.min(.2,(now-this.time)/1000));
    const speed=distance/dt;
    const cutoff=2.2+Math.min(18,speed*12);
    const alpha=1-Math.exp(-2*Math.PI*cutoff*dt);
    this.point={x:this.point.x+alpha*(p.x-this.point.x),y:this.point.y+alpha*(p.y-this.point.y)};
    this.raw=p;this.time=now;
    return {...this.point};
  }
}
