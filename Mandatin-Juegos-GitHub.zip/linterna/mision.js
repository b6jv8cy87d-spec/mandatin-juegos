function openMissions() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('mandatin-linterna', 1);
    request.onupgradeneeded = () => request.result.createObjectStore('missions');
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function savedMission(mission) {
  const db = await openMissions();
  try {
    return await new Promise((resolve, reject) => {
      const write = mission !== undefined;
      const transaction = db.transaction('missions', write ? 'readwrite' : 'readonly');
      const missions = transaction.objectStore('missions');
      const operation = write ? missions.put(mission, 'classroom') : missions.get('classroom');
      transaction.oncomplete = () => resolve(operation.result);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    db.close();
  }
}
