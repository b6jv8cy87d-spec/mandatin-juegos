const clamp = (value) => Math.min(1, Math.max(0, value));
const distance = (a, b, aspect = 1) => Math.hypot((a.x - b.x) * aspect, a.y - b.y);

export function handsByPlayer(hands, players, mirrored, previous = []) {
  const slots = Array(players).fill(null);
  for (const hand of hands) {
    const wrist = hand[0];
    if (!wrist || !hand[8] || !hand[17]) continue;
    const x = mirrored ? 1 - wrist.x : wrist.x;
    // Assign by wrist, so an index finger can reach the edge without changing players.
    const index = players === 1 || x < 0.5 ? 0 : 1;
    const candidate = slots[index];
    const reference = previous[index] || { x: mirrored ? 1 - (index + 0.5) / players : (index + 0.5) / players, y: 0.5 };
    if (!candidate || distance(wrist, reference) < distance(candidate[0], reference)) slots[index] = hand;
  }
  return slots;
}

export function handInput(hand, { players, index, mirrored, aspect, pinching }) {
  const tip = hand[8];
  const x = mirrored ? 1 - tip.x : tip.x;
  const palm = Math.max(0.001, distance(hand[0], hand[9], aspect), distance(hand[5], hand[17], aspect));
  return {
    // Leave a margin in each camera lane so the image edges are reachable.
    point: { x: clamp((x * players - index - 0.055) / 0.89), y: clamp((tip.y - 0.065) / 0.87) },
    motion: { x: tip.x, y: tip.y / aspect },
    pinch: distance(hand[4], tip, aspect) / palm < (pinching ? 0.46 : 0.31)
  };
}

export class Flashlight {
  constructor() { this.reset(); }

  reset() {
    this.burnedOut = false;
    this.point = null;
    this.release();
  }

  release() {
    this.present = false;
    this.pinching = false;
    this.sample = null;
    this.fastFrames = 0;
    this.relampAt = -Infinity;
  }

  ignite(now) {
    this.burnedOut = false;
    this.fastFrames = 0;
    this.relampAt = now;
  }

  move({ point, motion = point, pinch = false }, now) {
    const reactivated = pinch && !this.pinching;
    this.pinching = pinch;
    this.present = true;
    if (reactivated) this.ignite(now);

    const elapsed = this.sample ? now - this.sample.at : Infinity;
    if (elapsed >= 34) {
      if (elapsed <= 350 && now - this.relampAt > 170 && !this.burnedOut) {
        const speed = distance(motion, this.sample.motion) * 1000 / elapsed;
        this.fastFrames = speed >= 1.65 ? this.fastFrames + 1 : 0;
        if (this.fastFrames >= 2 || speed >= 3.1) this.burnedOut = true;
      } else {
        this.fastFrames = 0;
      }
      this.sample = { at: now, motion };
    }

    const prior = this.point;
    // Slight smoothing reduces the visible shake of the beam.
    this.point = !prior || elapsed > 350 ? point : {
      x: prior.x + (point.x - prior.x) * 0.78,
      y: prior.y + (point.y - prior.y) * 0.78
    };
  }

  get lit() { return this.present && !this.burnedOut; }
}
