// MediaPipe's WASM loader uses importScripts(), which requires a classic worker.
// The published CommonJS bundle exposes its API through `exports` here.
var exports = {};
// This CDN serves the CJS bundle as JavaScript; jsDelivr serves it as application/node.
importScripts("https://unpkg.com/@mediapipe/tasks-vision@0.10.8/vision_bundle.cjs");
const { FilesetResolver, HandLandmarker } = exports;

let handLandmarker = null;

async function createLandmarker(vision, delegate) {
  return HandLandmarker.createFromOptions(vision, {
    baseOptions: {
      modelAssetPath: "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
      delegate
    },
    runningMode: "VIDEO",
    numHands: 1,
    minHandDetectionConfidence: 0.45,
    minHandPresenceConfidence: 0.45,
    minTrackingConfidence: 0.45
  });
}

async function initialize() {
  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8/wasm"
  );

  let lastError = null;
  for (const delegate of ["GPU", "CPU"]) {
    try {
      handLandmarker = await createLandmarker(vision, delegate);
      self.postMessage({ type: "READY", delegate });
      return;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("No se pudo iniciar el modelo de manos.");
}

function detect(bitmap, timestamp, epoch) {
  try {
    const result = handLandmarker.detectForVideo(bitmap, timestamp);
    bitmap.close();

    if (!result?.landmarks?.length) {
      self.postMessage({ type: "RESULT", tracking: false, timestamp, epoch });
      return;
    }

    const landmarks = result.landmarks[0].map(({ x, y }) => ({ x, y }));
    const indexTip = landmarks[8];
    self.postMessage({
      type: "RESULT",
      timestamp, epoch,
      tracking: true,
      landmarks,
      coords: { x: 1 - indexTip.x, y: indexTip.y, score: 1 }
    });
  } catch (error) {
    bitmap.close();
    self.postMessage({ type: "ERROR", message: error.message, epoch });
  }
}

self.onmessage = async ({ data }) => {
  if (data.type === "INIT") {
    try {
      await initialize();
    } catch (error) {
      self.postMessage({ type: "INIT_ERROR", message: error.message });
    }
  } else if (data.type === "DETECT" && handLandmarker) {
    detect(data.bitmap, data.timestamp, data.epoch);
  }
};
