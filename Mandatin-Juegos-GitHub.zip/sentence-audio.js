export class SentenceAudio {
  constructor() { this.muted=false; }
  init() {
    try {
      const Audio=window.AudioContext||window.webkitAudioContext;
      if(!Audio)return;
      this.context ||= new Audio();
      if(this.context.state==='suspended')this.context.resume().catch(()=>{});
    } catch { /* Playing remains available without audio. */ }
  }
  play(cue) {
    if(this.muted)return;
    this.init(); if(!this.context)return;
    const sequences={place:[660,880],warning:[220,330,220],jet:[110,165,220],trick:[740,554,370,554],win:[523,659,784,1046],wrong:[220,165]};
    const notes=sequences[cue]||[440];
    notes.forEach((freq,i)=>{
      const osc=this.context.createOscillator(),gain=this.context.createGain();
      const t=this.context.currentTime+i*(cue==='trick'?.20:.10),duration=cue==='jet'?.4:.17;
      osc.type=['jet','trick'].includes(cue)?'triangle':'sine';osc.frequency.setValueAtTime(freq,t);
      if(cue==='jet')osc.frequency.exponentialRampToValueAtTime(60,t+duration);
      gain.gain.setValueAtTime(0,t);gain.gain.linearRampToValueAtTime(.08,t+.012);gain.gain.exponentialRampToValueAtTime(.001,t+duration);
      osc.connect(gain);gain.connect(this.context.destination);osc.start(t);osc.stop(t+duration+.02);
      osc.onended=()=>{osc.disconnect();gain.disconnect();};
    });
  }
  toggle() { this.muted=!this.muted;return this.muted; }
}
